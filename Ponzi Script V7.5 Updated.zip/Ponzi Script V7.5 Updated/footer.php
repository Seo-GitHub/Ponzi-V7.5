<?php
include "config.php";
$rs=mysql_query("select ID,BannerURL from membersbanners where remaining>0 and approved=1 order by rand() limit 0,$showban");
while($arr=mysql_fetch_array($rs)) {
echo "<br><center><a href=$siteurl/trr.php?id=$arr[0] target=_blank><img src=$arr[1] width=468 height=60 border=0></a><br></center><br>";
$rsu=mysql_query("update membersbanners set remaining=remaining-1 where ID=$arr[0]");
}
mysql_close($dbconnect);
?>
</div>
			<div class="clear-both"></div>
		</div>
        </div>
	
   <div id ="footer-bg">
	<div id="footer">
		<div><img src="images/footer.jpg" /></div>
		<div class="footer-link-text"><a href="index.php">Home</a> | <a href="faq.php">FAQs</a> | <a href="testimonials.php">Testimonials</a> | <a href="join.php">Join Now</a> | <a href="login.php">Login</a> | <a href="contactus.php">Contact Us</a> </div>
	</div>
	
   </div>
        
   
</body>
</html>