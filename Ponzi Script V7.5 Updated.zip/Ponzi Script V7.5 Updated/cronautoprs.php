<?php
include "config.php";
$last3days=date ( "Y-m-d H:i:s", mktime (date("H"),date("i"),date("s"),date("m"),date("d")-$autoapprovaldays,date("Y")));
$rsuser=mysql_query("select * from transaction where Date<'$last3days'");
while($arruser=mysql_fetch_array($rsuser)) {
$user=$arruser[1];
$tablee="matrix$arruser[3]";
$mid=$arruser[3];
$acountid=$arruser[6];
$refid=$arruser[5];

if($arruser[2]==""&&$arruser[7]=="") { // auto deleting pending gift
$rsmu=mysql_query("select ref_by from $tablee where ID=$acountid");
if(mysql_num_rows($rsmu)>0) {
$arrmu=mysql_fetch_array($rsmu);
$refid=$arrmu[0];
}
assignreferralss($acountid,$refid,1,1,$arruser[3]);
mysql_query("delete from $tablee where ID=$arruser[6]");
mysql_query("delete from gifts where posid=$arruser[6]");
mysql_query("delete from transaction where ID=$arruser[0]");

} else {	// auto approving pending gift

$rsm=mysql_query("select * from membershiplevels where ID=$mid");
$arrm=mysql_fetch_array($rsm);
$textcreditsentry=$arrm[49];
$bannercreditsentry=$arrm[50];
$welcomemail=$arrm[70];

if($welcomemail==1) {
matrixmail($acountid,$user,$mid,1);
}

$today=date ( "Y-m-d H:i:s", mktime (date("H"),date("i"),date("s"),date("m"),date("d"),date("Y")));
mysql_query("update $tablee set CDate='$today' where ID=$arruser[6]");
mysql_query("update gifts set ADate='$today',approved=1 where posid=$arruser[6]");
mysql_query("update users set banners=banners+$bannercreditsentry,textads=textads+$textcreditsentry,status=2 where Username='$user'");

$acountid=$arruser[6];
$refid=$arruser[5];
$rsmu=mysql_query("select ref_by from $tablee where ID=$acountid");
if(mysql_num_rows($rsmu)>0) {
$arrmu=mysql_fetch_array($rsmu);
$refid=$arrmu[0];
}
rassignreferrals($acountid,$refid,1,1,$arruser[3]);

// Sending email only on auto approval
if($arruser[5]>0) {
$rsg=mysql_query("select * from gifts where posid=$arruser[6]");
$arrg=mysql_fetch_array($rsg);
if($arrg[2]!="admin") {

$rs2=mysql_query("select * from users where Username='$user'");
if(mysql_num_rows($rs2)>0) {
$rs=mysql_fetch_array($rs2);
}

$rs1=mysql_query("select * from users where Username='$arrg[2]'");
if(mysql_num_rows($rs1)>0) {
$arr1=mysql_fetch_array($rs1);
  $to = $arr1[7];
$message1=$message11;
$message1=str_replace("{name}","$arr1[1]",$message1);
$message1=str_replace("{email}","$arr1[7]",$message1);
$message1=str_replace("{username}","$arr1[8]",$message1);
$message1=str_replace("{password}","$arr1[9]",$message1);
$message1=str_replace("{sitename}","$sitename",$message1);
$message1=str_replace("{siteurl}","$siteurl",$message1);
$message1=str_replace("{refname}","$rs[1]",$message1);
$message1=str_replace("{refemail}","$rs[7]",$message1);
$message1=str_replace("{refusername}","$rs[8]",$message1);

$subject1=str_replace("{name}","$arr1[1]",$subject11);
$subject1=str_replace("{email}","$arr1[7]",$subject1);
$subject1=str_replace("{username}","$arr1[8]",$subject1);
$subject1=str_replace("{password}","$arr1[9]",$subject1);
$subject1=str_replace("{sitename}","$sitename",$subject1);
$subject1=str_replace("{siteurl}","$siteurl",$subject1);
$subject1=str_replace("{refname}","$rs[1]",$subject1);
$subject1=str_replace("{refemail}","$rs[7]",$subject1);
$subject1=str_replace("{refusername}","$rs[8]",$subject1);
      $message=stripslashes($message1);
      $subject=stripslashes($subject1);

$from=$webmasteremail;
    	$header = "From: $sitename<$from>\n";
if($eformat11==1) 
	$header .="Content-type: text/plain; charset=iso-8859-1\n";
else
	$header .="Content-type: text/html; charset=iso-8859-1\n";
	$header .= "Reply-To: <$from>\n";
	$header .= "X-Sender: <$from>\n";
	$header .= "X-Mailer: PHP4\n";
	$header .= "X-Priority: 3\n";
	$header .= "Return-Path: <$from>\n";

  mail($to,$subject,$message,$header);
  }
}
}
// end of Sending email only on auto approval
mysql_query("delete from transaction where ID=$arruser[0]");
}

} //end of process
echo "<br><b>Process Completed</b><br>";

function assignreferralss($acountid,$refid,$status,$level,$mid) {
include "config.php";
$tablee="matrix$mid";
$rsm=mysql_query("select * from membershiplevels where ID=$mid");
$arrm=mysql_fetch_array($rsm);
$mname=$arrm[1];
$fee=$arrm[2];
$matrixtype=$arrm[3];
$levels=$arrm[4];
$forcedmatrix=$arrm[5];

if($level < ($levels+1)) {
$referralid=0;
$rs=mysql_query("Select * from $tablee where ID=".$refid);
if(mysql_num_rows($rs)>0)
{
$arr=mysql_fetch_array($rs);
if($level==1) {
$rs=mysql_query("Update $tablee set Level1=Level1-1 where ID=".$refid);
}
elseif($level==2) {
$rs=mysql_query("Update $tablee set Level2=Level2-1 where ID=".$refid);
}
elseif($level==3) {
$rs=mysql_query("Update $tablee set Level3=Level3-1 where ID=".$refid);
}
elseif($level==4) {
$rs=mysql_query("Update $tablee set Level4=Level4-1 where ID=".$refid);
}
elseif($level==5) {
$rs=mysql_query("Update $tablee set Level5=Level5-1 where ID=".$refid);
}
elseif($level==6) {
$rs=mysql_query("Update $tablee set Level6=Level6-1 where ID=".$refid);
}
elseif($level==7) {
$rs=mysql_query("Update $tablee set Level7=Level7-1 where ID=".$refid);
}
elseif($level==8) {
$rs=mysql_query("Update $tablee set Level8=Level8-1 where ID=".$refid);
}
elseif($level==9) {
$rs=mysql_query("Update $tablee set Level9=Level9-1 where ID=".$refid);
}
elseif($level==10) {
$rs=mysql_query("Update $tablee set Level10=Level10-1 where ID=".$refid);
}

if($arr[3]!=0) {
$referralid=$arr[3];
}

if($referralid!=0) {
assignreferralss($acountid,$referralid,1,$level+1,$mid);
}

}
}

}//end of function

function assignreferrals($acountid,$refid,$status,$level,$mid) {
 include "config.php";
$tablee="matrix$mid";
$rsm=mysql_query("select * from membershiplevels where ID=$mid");
$arrm=mysql_fetch_array($rsm);
$mname=$arrm[1];
$fee=$arrm[2];
$matrixtype=$arrm[3];
$levels=$arrm[4];
$forcedmatrix=$arrm[5];
$refbonus=$arrm[84];
$refbonuspaid=$arrm[83];
$payouttype=$arrm[6];
$matrixbonus=$arrm[7];
$matchingbonus=$arrm[8];
$level1=$arrm[9];
$level2=$arrm[10];
$level3=$arrm[11];
$level4=$arrm[12];
$level5=$arrm[13];
$level6=$arrm[14];
$level7=$arrm[15];
$level8=$arrm[16];
$level9=$arrm[17];
$level10=$arrm[18];
$level1m=$arrm[19];
$level2m=$arrm[20];
$level3m=$arrm[21];
$level4m=$arrm[22];
$level5m=$arrm[23];
$level6m=$arrm[24];
$level7m=$arrm[25];
$level8m=$arrm[26];
$level9m=$arrm[27];
$level10m=$arrm[28];
$level1c=$arrm[29];
$level2c=$arrm[30];
$level3c=$arrm[31];
$level4c=$arrm[32];
$level5c=$arrm[33];
$level6c=$arrm[34];
$level7c=$arrm[35];
$level8c=$arrm[36];
$level9c=$arrm[37];
$level10c=$arrm[38];
$level1cm=$arrm[39];
$level2cm=$arrm[40];
$level3cm=$arrm[41];
$level4cm=$arrm[42];
$level5cm=$arrm[43];
$level6cm=$arrm[44];
$level7cm=$arrm[45];
$level8cm=$arrm[46];
$level9cm=$arrm[47];
$level10cm=$arrm[48];

$textcreditsentry=$arrm[49];
$bannercreditsentry=$arrm[50];
$textcreditscycle=$arrm[51];
$bannercreditscycle=$arrm[52];

$reentry=$arrm[53];
$reentrynum=$arrm[54];
$entry1=$arrm[55];
$entry1num=$arrm[56];
$matrixid1=$arrm[57];
$entry2=$arrm[58];
$entry2num=$arrm[59];
$matrixid2=$arrm[60];
$entry3=$arrm[61];
$entry3num=$arrm[62];
$matrixid3=$arrm[63];
$entry4=$arrm[64];
$entry4num=$arrm[65];
$matrixid4=$arrm[66];
$entry5=$arrm[67];
$entry5num=$arrm[68];
$matrixid5=$arrm[69];
$welcomemail=$arrm[70];
$subject1=stripslashes($arrm[71]);
$message1=stripslashes($arrm[72]);
$eformat1=$arrm[73];
$cyclemail=$arrm[74];
$subject2=stripslashes($arrm[75]);
$message2=stripslashes($arrm[76]);
$eformat2=$arrm[77];
$cyclemailsponsor=$arrm[78];
$subject3=stripslashes($arrm[79]);
$message3=stripslashes($arrm[80]);
$eformat3=$arrm[81];

$f1=$forcedmatrix;
$f2=$forcedmatrix*$forcedmatrix;
$f3=$forcedmatrix*$forcedmatrix*$forcedmatrix;
$f4=$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix;
$f5=$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix;
$f6=$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix;
$f7=$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix;
$f8=$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix;
$f9=$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix;
$f10=$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix;

if($levels==1) $fquery="Level1<$forcedmatrix"; 
elseif($levels==2) $fquery="Level2<$f2";
elseif($levels==3) $fquery="Level3<$f3";
elseif($levels==4) $fquery="Level4<$f4";
elseif($levels==5) $fquery="Level5<$f5";
elseif($levels==6) $fquery="Level6<$f6";
elseif($levels==7) $fquery="Level7<$f7";
elseif($levels==8) $fquery="Level8<$f8";
elseif($levels==9) $fquery="Level9<$f9";
elseif($levels==10) $fquery="Level10<$f10";

if($status==0) {
$rs=mysql_query("Update $tablee set ref_by=".$refid." where ID=".$acountid);
}

if($level < ($levels+1)) {
$referralid=0;
$rs=mysql_query("Select * from $tablee where ID=".$refid);
if(mysql_num_rows($rs)>0)
{
$arr=mysql_fetch_array($rs);
if($level==1) {
$rs=mysql_query("Update $tablee set Level1=Level1+1 where ID=".$refid);
$bonus=$level1;
if($bonus>0) creategift($bonus,$acountid,$refid,$mid);
}
elseif($level==2) {
$rs=mysql_query("Update $tablee set Level2=Level2+1 where ID=".$refid);
$bonus=$level2;
if($bonus>0) creategift($bonus,$acountid,$refid,$mid);
}
elseif($level==3) {
$rs=mysql_query("Update $tablee set Level3=Level3+1 where ID=".$refid);
$bonus=$level3;
if($bonus>0) creategift($bonus,$acountid,$refid,$mid);
}
elseif($level==4) {
$rs=mysql_query("Update $tablee set Level4=Level4+1 where ID=".$refid);
$bonus=$level4;
if($bonus>0) creategift($bonus,$acountid,$refid,$mid);
}
elseif($level==5) {
$rs=mysql_query("Update $tablee set Level5=Level5+1 where ID=".$refid);
$bonus=$level5;
if($bonus>0) creategift($bonus,$acountid,$refid,$mid);
}
elseif($level==6) {
$rs=mysql_query("Update $tablee set Level6=Level6+1 where ID=".$refid);
$bonus=$level6;
if($bonus>0) creategift($bonus,$acountid,$refid,$mid);
}
elseif($level==7) {
$rs=mysql_query("Update $tablee set Level7=Level7+1 where ID=".$refid);
$bonus=$level7;
if($bonus>0) creategift($bonus,$acountid,$refid,$mid);
}
elseif($level==8) {
$rs=mysql_query("Update $tablee set Level8=Level8+1 where ID=".$refid);
$bonus=$level8;
if($bonus>0) creategift($bonus,$acountid,$refid,$mid);
}
elseif($level==9) {
$rs=mysql_query("Update $tablee set Level9=Level9+1 where ID=".$refid);
$bonus=$level9;
if($bonus>0) creategift($bonus,$acountid,$refid,$mid);
}
elseif($level==10) {
$rs=mysql_query("Update $tablee set Level10=Level10+1 where ID=".$refid);
$bonus=$level10;
if($bonus>0) creategift($bonus,$acountid,$refid,$mid);
}

if($arr[3]!=0) {
$referralid=$arr[3];
}

if($referralid!=0) {
assignreferrals($acountid,$referralid,1,$level+1,$mid);
}

}
}

}//end of function

function newupline($acountid,$ref_by,$mid)
{
include "config.php";
$check=0;
$rsm=mysql_query("select * from membershiplevels where ID=$mid");
$arrm=mysql_fetch_array($rsm);
$levels=$arrm[4];
$forcedmatrix=$arrm[5];
$tablee="matrix$mid";
$checkid=0;
//Check for 1st level spillover
$rs=mysql_query("select ID from $tablee where Level1<".$forcedmatrix." and ref_by=".$ref_by." and ID<>'$acountid' order by ID limit 0,1");

if(mysql_num_rows($rs)>0) {
$arr=mysql_fetch_array($rs);
$check=1;
$checkid=$arr[0];
}

//Check for 2nd level spillover
else {
$rs=mysql_query("select ID from $tablee where ref_by=".$ref_by." and ID<>'$acountid' order by ID");

while($arr=mysql_fetch_array($rs)) {
  $rs1=mysql_query("select ID from $tablee where Level1<".$forcedmatrix." and ref_by=".$arr[0]." order by ID limit 0,1");

 if(mysql_num_rows($rs1)>0) {
  $arr1=mysql_fetch_array($rs1);
if($check==0) {
  $check=1;
  $checkid=$arr1[0];
}
  break;
 }
}//end of while

 //Check for 3rd level spillover
 if($check==0) {
  $rs=mysql_query("select ID from $tablee where ref_by=".$ref_by." and ID<>'$acountid' order by ID");
  while($arr=mysql_fetch_array($rs)) {

  $rs1=mysql_query("select ID from $tablee where ref_by=".$arr[0]." order by ID");
   while($arr1=mysql_fetch_array($rs1)) {
   $rs2=mysql_query("select ID from $tablee where Level1<".$forcedmatrix." and ref_by=".$arr1[0]." order by ID limit 0,1");

   if(mysql_num_rows($rs2)>0) {
    $arr2=mysql_fetch_array($rs2);
if($check==0) {
    $check=1;
    $checkid=$arr2[0];
}
    break;
   }
  }//while closing
 } //while closing  

   //Check for 4th level spillover
   if($check==0) {

  $rs=mysql_query("select ID from $tablee where ref_by=".$ref_by." and ID<>'$acountid' order by ID");
  while($arr=mysql_fetch_array($rs)) {

  $rs1=mysql_query("select ID from $tablee where ref_by=".$arr[0]." order by ID");
   while($arr1=mysql_fetch_array($rs1)) {

    $rs2=mysql_query("select ID from $tablee where ref_by=".$arr1[0]." order by ID");
     while($arr2=mysql_fetch_array($rs2)) {
     $rs3=mysql_query("select ID from $tablee where Level1<".$forcedmatrix." and ref_by=".$arr2[0]." order by ID limit 0,1");
     if(mysql_num_rows($rs3)>0) {
      $arr3=mysql_fetch_array($rs3);
if($check==0) {
      $check=1;
      $checkid=$arr3[0];
}
      break;
     }
   }
  }
 }
     //Check for 5th level spillover
     if($check==0) {
  $rs=mysql_query("select ID from $tablee where ref_by=".$ref_by." and ID<>'$acountid' order by ID");
  while($arr=mysql_fetch_array($rs)) {

  $rs1=mysql_query("select ID from $tablee where ref_by=".$arr[0]." order by ID");
   while($arr1=mysql_fetch_array($rs1)) {

    $rs2=mysql_query("select ID from $tablee where ref_by=".$arr1[0]." order by ID");
     while($arr2=mysql_fetch_array($rs2)) {

      $rs3=mysql_query("select ID from $tablee where ref_by=".$arr2[0]." order by ID");

       while($arr3=mysql_fetch_array($rs3)) {
       $rs4=mysql_query("select ID from $tablee where Level1<".$forcedmatrix." and ref_by=".$arr3[0]." order by ID limit 0,1");
       if(mysql_num_rows($rs4)>0) {
        $arr4=mysql_fetch_array($rs4);
if($check==0) {
        $check=1;
        $checkid=$arr4[0];
}
        break;
       } 
     }
    }
   }
  }
       //Check for 5th level spillover
  if($check==0) {
  $rs=mysql_query("select ID from $tablee where ref_by=".$ref_by." and ID<>'$acountid' order by ID");
  while($arr=mysql_fetch_array($rs)) {

  $rs1=mysql_query("select ID from $tablee where ref_by=".$arr[0]." order by ID");
   while($arr1=mysql_fetch_array($rs1)) {

    $rs2=mysql_query("select ID from $tablee where ref_by=".$arr1[0]." order by ID");
     while($arr2=mysql_fetch_array($rs2)) {

      $rs3=mysql_query("select ID from $tablee where ref_by=".$arr2[0]." order by ID");
       while($arr3=mysql_fetch_array($rs3)) {

        $rs4=mysql_query("select ID from $tablee where ref_by=".$arr3[0]." order by ID");
         while($arr4=mysql_fetch_array($rs4)) {

         $rs5=mysql_query("select ID from $tablee where Level1<".$forcedmatrix." and ref_by=".$arr4[0]." order by ID limit 0,1");
         if(mysql_num_rows($rs5)>0) {
          $arr5=mysql_fetch_array($rs5);
if($check==0) {
          $check=1;
          $checkid=$arr5[0];
}
          break;
         } 
	}
       }
      }
     }
    }
         //Check for 6th level spillover
  if($check==0) {
  $rs=mysql_query("select ID from $tablee where ref_by=".$ref_by." and ID<>'$acountid' order by ID");
  while($arr=mysql_fetch_array($rs)) {

  $rs1=mysql_query("select ID from $tablee where ref_by=".$arr[0]." order by ID");
   while($arr1=mysql_fetch_array($rs1)) {

    $rs2=mysql_query("select ID from $tablee where ref_by=".$arr1[0]." order by ID");
     while($arr2=mysql_fetch_array($rs2)) {

      $rs3=mysql_query("select ID from $tablee where ref_by=".$arr2[0]." order by ID");
       while($arr3=mysql_fetch_array($rs3)) {

        $rs4=mysql_query("select ID from $tablee where ref_by=".$arr3[0]." order by ID");
         while($arr4=mysql_fetch_array($rs4)) {

          $rs5=mysql_query("select ID from $tablee where ref_by=".$arr4[0]." order by ID");
           while($arr5=mysql_fetch_array($rs5)) {
           $rs6=mysql_query("select ID from $tablee where Level1<".$forcedmatrix." and ref_by=".$arr5[0]." order by ID limit 0,1");
           if(mysql_num_rows($rs6)>0) {
            $arr6=mysql_fetch_array($rs6);
if($check==0) {
            $check=1;
            $checkid=$arr6[0];
}
            break;
           } 
	 }
	}
       }
      }
     }
    }
  //Check for 7th level spillover
    if($check==0) {
  $rs=mysql_query("select ID from $tablee where ref_by=".$ref_by." and ID<>'$acountid' order by ID");
  while($arr=mysql_fetch_array($rs)) {

  $rs1=mysql_query("select ID from $tablee where ref_by=".$arr[0]." order by ID");
   while($arr1=mysql_fetch_array($rs1)) {

    $rs2=mysql_query("select ID from $tablee where ref_by=".$arr1[0]." order by ID");
     while($arr2=mysql_fetch_array($rs2)) {

      $rs3=mysql_query("select ID from $tablee where ref_by=".$arr2[0]." order by ID");
       while($arr3=mysql_fetch_array($rs3)) {

        $rs4=mysql_query("select ID from $tablee where ref_by=".$arr3[0]." order by ID");
         while($arr4=mysql_fetch_array($rs4)) {

          $rs5=mysql_query("select ID from $tablee where ref_by=".$arr4[0]." order by ID");
           while($arr5=mysql_fetch_array($rs5)) {

            $rs6=mysql_query("select ID from $tablee where ref_by=".$arr5[0]." order by ID");
             while($arr6=mysql_fetch_array($rs6)) {
             $rs7=mysql_query("select ID from $tablee where Level1<".$forcedmatrix." and ref_by=".$arr6[0]." order by ID limit 0,1");
             if(mysql_num_rows($rs7)>0) {
              $arr7=mysql_fetch_array($rs7);
if($check==0) {
              $check=1;
              $checkid=$arr7[0];
}
              break;
             } 
	    }
	   }
	  }
	 }
	}
       }
      }
             //Check for 8th level spillover
  if($check==0) {
  $rs=mysql_query("select ID from $tablee where ref_by=".$ref_by." and ID<>'$acountid' order by ID");
  while($arr=mysql_fetch_array($rs)) {

  $rs1=mysql_query("select ID from $tablee where ref_by=".$arr[0]." order by ID");
   while($arr1=mysql_fetch_array($rs1)) {

    $rs2=mysql_query("select ID from $tablee where ref_by=".$arr1[0]." order by ID");
     while($arr2=mysql_fetch_array($rs2)) {

      $rs3=mysql_query("select ID from $tablee where ref_by=".$arr2[0]." order by ID");
       while($arr3=mysql_fetch_array($rs3)) {

        $rs4=mysql_query("select ID from $tablee where ref_by=".$arr3[0]." order by ID");
         while($arr4=mysql_fetch_array($rs4)) {

          $rs5=mysql_query("select ID from $tablee where ref_by=".$arr4[0]." order by ID");
           while($arr5=mysql_fetch_array($rs5)) {

            $rs6=mysql_query("select ID from $tablee where ref_by=".$arr5[0]." order by ID");
             while($arr6=mysql_fetch_array($rs6)) {

              $rs7=mysql_query("select ID from $tablee where ref_by=".$arr6[0]." order by ID");
               while($arr7=mysql_fetch_array($rs7)) {
               $rs8=mysql_query("select ID from $tablee where Level1<".$forcedmatrix." and ref_by=".$arr7[0]." order by ID limit 0,1");
               if(mysql_num_rows($rs8)>0) {
                $arr8=mysql_fetch_array($rs8);
if($check==0) {
                $check=1;
                $checkid=$arr8[0];
}
                break;
               } 
	      }
             }
            }
           }
          }
         }
        }
       }

               //Check for 9th level spillover
    if($check==0) {
  $rs=mysql_query("select ID from $tablee where ref_by=".$ref_by." and ID<>'$acountid' order by ID");
  while($arr=mysql_fetch_array($rs)) {

  $rs1=mysql_query("select ID from $tablee where ref_by=".$arr[0]." order by ID");
   while($arr1=mysql_fetch_array($rs1)) {

    $rs2=mysql_query("select ID from $tablee where ref_by=".$arr1[0]." order by ID");
     while($arr2=mysql_fetch_array($rs2)) {

      $rs3=mysql_query("select ID from $tablee where ref_by=".$arr2[0]." order by ID");
       while($arr3=mysql_fetch_array($rs3)) {

        $rs4=mysql_query("select ID from $tablee where ref_by=".$arr3[0]." order by ID");
         while($arr4=mysql_fetch_array($rs4)) {

          $rs5=mysql_query("select ID from $tablee where ref_by=".$arr4[0]." order by ID");
           while($arr5=mysql_fetch_array($rs5)) {

            $rs6=mysql_query("select ID from $tablee where ref_by=".$arr5[0]." order by ID");
             while($arr6=mysql_fetch_array($rs6)) {

              $rs7=mysql_query("select ID from $tablee where ref_by=".$arr6[0]." order by ID");
               while($arr7=mysql_fetch_array($rs7)) {

                $rs8=mysql_query("select ID from $tablee where ref_by=".$arr7[0]." order by ID");
                 while($arr8=mysql_fetch_array($rs8)) {
                 $rs9=mysql_query("select ID from $tablee where Level1<".$forcedmatrix." and ref_by=".$arr8[0]." order by ID limit 0,1");
                 if(mysql_num_rows($rs9)>0) {
                  $arr9=mysql_fetch_array($rs9);
if($check==0) {
                  $check=1;
                  $checkid=$arr9[0];
}
                  break;
                 } 
		}
	       }
              }
             }
            }
           }
          }
	 }
	}
               } // end of 8th spillover else

             } // end of 8th spillover else

           } // end of 7th spillover else

         } // end of 6th spillover else

       } // end of 5th spillover else

     } // end of 5th spillover else

   } // end of 4th spillover else
 } // end of 3rd spillover else


}  //end of else


if($check!=1) {
$rs2=mysql_query("select ID from $tablee where Level1<'$forcedmatrix' and ID <>'$acountid' order by ID limit 0,1");

$arr2=mysql_fetch_array($rs2);
$checkid=$arr2[0];
}
return $checkid;
}


function rassignreferrals($acountid,$refid,$status,$level,$mid) {
 include "config.php";
$tablee="matrix$mid";
$rsm=mysql_query("select * from membershiplevels where ID=$mid");
$arrm=mysql_fetch_array($rsm);
$mname=$arrm[1];
$fee=$arrm[2];
$matrixtype=$arrm[3];
$levels=$arrm[4];
$forcedmatrix=$arrm[5];
$refbonus=$arrm[84];
$refbonuspaid=$arrm[83];
$payouttype=$arrm[6];
$matrixbonus=$arrm[7];
$matchingbonus=$arrm[8];
$level1=$arrm[9];
$level2=$arrm[10];
$level3=$arrm[11];
$level4=$arrm[12];
$level5=$arrm[13];
$level6=$arrm[14];
$level7=$arrm[15];
$level8=$arrm[16];
$level9=$arrm[17];
$level10=$arrm[18];
$level1m=$arrm[19];
$level2m=$arrm[20];
$level3m=$arrm[21];
$level4m=$arrm[22];
$level5m=$arrm[23];
$level6m=$arrm[24];
$level7m=$arrm[25];
$level8m=$arrm[26];
$level9m=$arrm[27];
$level10m=$arrm[28];
$level1c=$arrm[29];
$level2c=$arrm[30];
$level3c=$arrm[31];
$level4c=$arrm[32];
$level5c=$arrm[33];
$level6c=$arrm[34];
$level7c=$arrm[35];
$level8c=$arrm[36];
$level9c=$arrm[37];
$level10c=$arrm[38];
$level1cm=$arrm[39];
$level2cm=$arrm[40];
$level3cm=$arrm[41];
$level4cm=$arrm[42];
$level5cm=$arrm[43];
$level6cm=$arrm[44];
$level7cm=$arrm[45];
$level8cm=$arrm[46];
$level9cm=$arrm[47];
$level10cm=$arrm[48];

$textcreditsentry=$arrm[49];
$bannercreditsentry=$arrm[50];
$textcreditscycle=$arrm[51];
$bannercreditscycle=$arrm[52];

$reentry=$arrm[53];
$reentrynum=$arrm[54];
$entry1=$arrm[55];
$entry1num=$arrm[56];
$matrixid1=$arrm[57];
$entry2=$arrm[58];
$entry2num=$arrm[59];
$matrixid2=$arrm[60];
$entry3=$arrm[61];
$entry3num=$arrm[62];
$matrixid3=$arrm[63];
$entry4=$arrm[64];
$entry4num=$arrm[65];
$matrixid4=$arrm[66];
$entry5=$arrm[67];
$entry5num=$arrm[68];
$matrixid5=$arrm[69];
$welcomemail=$arrm[70];
$subject1=stripslashes($arrm[71]);
$message1=stripslashes($arrm[72]);
$eformat1=$arrm[73];
$cyclemail=$arrm[74];
$subject2=stripslashes($arrm[75]);
$message2=stripslashes($arrm[76]);
$eformat2=$arrm[77];
$cyclemailsponsor=$arrm[78];
$subject3=stripslashes($arrm[79]);
$message3=stripslashes($arrm[80]);
$eformat3=$arrm[81];

$f1=$forcedmatrix;
$f2=$forcedmatrix*$forcedmatrix;
$f3=$forcedmatrix*$forcedmatrix*$forcedmatrix;
$f4=$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix;
$f5=$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix;
$f6=$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix;
$f7=$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix;
$f8=$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix;
$f9=$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix;
$f10=$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix*$forcedmatrix;

if($levels==1) $fquery="Level1<$forcedmatrix"; 
elseif($levels==2) $fquery="Level2<$f2";
elseif($levels==3) $fquery="Level3<$f3";
elseif($levels==4) $fquery="Level4<$f4";
elseif($levels==5) $fquery="Level5<$f5";
elseif($levels==6) $fquery="Level6<$f6";
elseif($levels==7) $fquery="Level7<$f7";
elseif($levels==8) $fquery="Level8<$f8";
elseif($levels==9) $fquery="Level9<$f9";
elseif($levels==10) $fquery="Level10<$f10";

if($status==0) {
$rs=mysql_query("Update $tablee set ref_by=".$refid." where ID=".$acountid);
}

if($level < ($levels+1)) {
$referralid=0;
$rs=mysql_query("Select * from $tablee where ID=".$refid);
if(mysql_num_rows($rs)>0)
{
$arr=mysql_fetch_array($rs);
$err=0;
$rsb=mysql_query("select * from $tablee where Username='$arr[2]'");
if(mysql_num_rows($rsb)>0) $err=0;
elseif($nonmatrixmatch==1) $err=0;
else $err=1;

if($level==1) {
 	$bonus=$level1;
	mysql_query("update $tablee set Total=Total+$bonus where ID=".$refid);
	mysql_query("update users set Total=Total+$bonus,Unpaid=Unpaid+$bonus where Username='$arr[1]'");
}
elseif($level==2) {
 	$bonus=$level2;
	mysql_query("update $tablee set Total=Total+$bonus where ID=".$refid);
	mysql_query("update users set Total=Total+$bonus,Unpaid=Unpaid+$bonus where Username='$arr[1]'");
}
elseif($level==3) {
 	$bonus=$level3;
	mysql_query("update $tablee set Total=Total+$bonus where ID=".$refid);
	mysql_query("update users set Total=Total+$bonus,Unpaid=Unpaid+$bonus where Username='$arr[1]'");
}
elseif($level==4) {
 	$bonus=$level4;
	mysql_query("update $tablee set Total=Total+$bonus where ID=".$refid);
	mysql_query("update users set Total=Total+$bonus,Unpaid=Unpaid+$bonus where Username='$arr[1]'");
}
elseif($level==5) {
 	$bonus=$level5;
	mysql_query("update $tablee set Total=Total+$bonus where ID=".$refid);
	mysql_query("update users set Total=Total+$bonus,Unpaid=Unpaid+$bonus where Username='$arr[1]'");
}
elseif($level==6) {
 	$bonus=$level6;
	mysql_query("update $tablee set Total=Total+$bonus where ID=".$refid);
	mysql_query("update users set Total=Total+$bonus,Unpaid=Unpaid+$bonus where Username='$arr[1]'");
}
elseif($level==7) {
 	$bonus=$level7;
	mysql_query("update $tablee set Total=Total+$bonus where ID=".$refid);
	mysql_query("update users set Total=Total+$bonus,Unpaid=Unpaid+$bonus where Username='$arr[1]'");
}
elseif($level==8) {
 	$bonus=$level8;
	mysql_query("update $tablee set Total=Total+$bonus where ID=".$refid);
	mysql_query("update users set Total=Total+$bonus,Unpaid=Unpaid+$bonus where Username='$arr[1]'");
}
elseif($level==9) {
 	$bonus=$level9;
	mysql_query("update $tablee set Total=Total+$bonus where ID=".$refid);
	mysql_query("update users set Total=Total+$bonus,Unpaid=Unpaid+$bonus where Username='$arr[1]'");
}
elseif($level==10) {
 	$bonus=$level10;
	mysql_query("update $tablee set Total=Total+$bonus where ID=".$refid);
	mysql_query("update users set Total=Total+$bonus,Unpaid=Unpaid+$bonus where Username='$arr[1]'");
}


if($arr[3]!=0) {
$referralid=$arr[3];
}

if($referralid!=0) {
rassignreferrals($acountid,$referralid,1,$level+1,$mid);
}

}
}

}//end of function


function creategift($bonus,$acountid,$refid,$mid) {
include "config.php";
$tablee="matrix$mid";
$rsm=mysql_query("select * from membershiplevels where ID=$mid");
$arrm=mysql_fetch_array($rsm);
$mname=$arrm[1];
$fee=$arrm[2];
$matrixtype=$arrm[3];
$levels=$arrm[4];
$forcedmatrix=$arrm[5];

$fuser="";
$tuser="admin";
$rsf=mysql_query("select Username from $tablee where ID=$acountid");
if(mysql_num_rows($rsf)>0) {
$arrf=mysql_fetch_array($rsf);
$fuser=$arrf[0];
}
$rsf=mysql_query("select Username from $tablee where ID=$refid");
if(mysql_num_rows($rsf)>0) {
$arrf=mysql_fetch_array($rsf);
$tuser=$arrf[0];
}

mysql_query("insert into gifts(FUsername,TUsername,PaymentMode,TransID,Amount,matrixid,posid,approved,Date,ADate) values('$fuser','$tuser','','','$bonus',$mid,$acountid,0,'$today','$today')");
}
   
function matrixmail($b,$user,$mid,$mt) {
include "config.php";
$tablee="matrix$mid";
$rsm=mysql_query("select * from membershiplevels where ID=$mid");
$arrm=mysql_fetch_array($rsm);
$mname=$arrm[1];
$fee=$arrm[2];
$matrixtype=$arrm[3];
$levels=$arrm[4];
$forcedmatrix=$arrm[5];
$refbonus=$arrm[84];
$refbonuspaid=$arrm[83];
$payouttype=$arrm[6];
$matrixbonus=$arrm[7];
$matchingbonus=$arrm[8];
$level1=$arrm[9];
$level2=$arrm[10];
$level3=$arrm[11];
$level4=$arrm[12];
$level5=$arrm[13];
$level6=$arrm[14];
$level7=$arrm[15];
$level8=$arrm[16];
$level9=$arrm[17];
$level10=$arrm[18];
$level1m=$arrm[19];
$level2m=$arrm[20];
$level3m=$arrm[21];
$level4m=$arrm[22];
$level5m=$arrm[23];
$level6m=$arrm[24];
$level7m=$arrm[25];
$level8m=$arrm[26];
$level9m=$arrm[27];
$level10m=$arrm[28];
$level1c=$arrm[29];
$level2c=$arrm[30];
$level3c=$arrm[31];
$level4c=$arrm[32];
$level5c=$arrm[33];
$level6c=$arrm[34];
$level7c=$arrm[35];
$level8c=$arrm[36];
$level9c=$arrm[37];
$level10c=$arrm[38];
$level1cm=$arrm[39];
$level2cm=$arrm[40];
$level3cm=$arrm[41];
$level4cm=$arrm[42];
$level5cm=$arrm[43];
$level6cm=$arrm[44];
$level7cm=$arrm[45];
$level8cm=$arrm[46];
$level9cm=$arrm[47];
$level10cm=$arrm[48];

$textcreditsentry=$arrm[49];
$bannercreditsentry=$arrm[50];
$textcreditscycle=$arrm[51];
$bannercreditscycle=$arrm[52];

$reentry=$arrm[53];
$reentrynum=$arrm[54];
$entry1=$arrm[55];
$entry1num=$arrm[56];
$matrixid1=$arrm[57];
$entry2=$arrm[58];
$entry2num=$arrm[59];
$matrixid2=$arrm[60];
$entry3=$arrm[61];
$entry3num=$arrm[62];
$matrixid3=$arrm[63];
$entry4=$arrm[64];
$entry4num=$arrm[65];
$matrixid4=$arrm[66];
$entry5=$arrm[67];
$entry5num=$arrm[68];
$matrixid5=$arrm[69];
$welcomemail=$arrm[70];
$subject1=stripslashes($arrm[71]);
$message1=stripslashes($arrm[72]);
$eformat1=$arrm[73];
$cyclemail=$arrm[74];
$subject2=stripslashes($arrm[75]);
$message2=stripslashes($arrm[76]);
$eformat2=$arrm[77];
$cyclemailsponsor=$arrm[78];
$subject3=stripslashes($arrm[79]);
$message3=stripslashes($arrm[80]);
$eformat3=$arrm[81];

$err=0;
$rsp=mysql_query("select * from $tablee where ID=$b");
if(mysql_num_rows($rsp)>0) {
$arr1=mysql_fetch_array($rsp);

$rs=mysql_query("select * from users where Username='$arr1[1]'");
if(mysql_num_rows($rs)>0) {
$arr=mysql_fetch_array($rs);
$user=$arr[8];
$ref_by=$arr[11];
} else $err=1;

} else $err=1;

if($err==1) {
$rs=mysql_query("select * from users where Username='$user'");
if(mysql_num_rows($rs)>0) {
$arr=mysql_fetch_array($rs);
$user=$arr[8];
$ref_by=$arr[11];
$err=0;
} else $err=1;
}

$refname="";
if($mt==1) {
$message1=$message1;
$subject1=$subject1;
$eformat1=$eformat1;
}
elseif($mt==2) {
$message1=$message2;
$subject1=$subject2;
$eformat1=$eformat2;
}
elseif($mt==3) {
$message1=$message3;
$subject1=$subject3;
$eformat1=$eformat3;
$rsu=mysql_query("select Name from users where Usename='$ref_by'");
if(mysql_num_rows($rsu)>0) {
$arru=mysql_fetch_array($rsu);
$refname=$arru[0];
}
}

  $to = $arr[7];

$message1=str_replace("{name}","$arr[1]",$message1);
$message1=str_replace("{email}","$arr[7]",$message1);
$message1=str_replace("{username}","$arr[8]",$message1);
$message1=str_replace("{password}","$arr[9]",$message1);
$message1=str_replace("{id}","$b",$message1);
$message1=str_replace("{matrix}","$mname",$message1);
$message1=str_replace("{refname}","$refname",$message1);
$message1=str_replace("{sitename}","$sitename",$message1);
$message1=str_replace("{siteurl}","$siteurl",$message1);

$subject1=str_replace("{name}","$arr[1]",$subject1);
$subject1=str_replace("{email}","$arr[7]",$subject1);
$subject1=str_replace("{username}","$arr[8]",$subject1);
$subject1=str_replace("{password}","$arr[9]",$subject1);
$subject1=str_replace("{id}","$b",$subject1);
$subject1=str_replace("{matrix}","$mname",$subject1);
$subject1=str_replace("{refname}","$refname",$subject1);
$subject1=str_replace("{sitename}","$sitename",$subject1);
$subject1=str_replace("{siteurl}","$siteurl",$subject1);
      $message=stripslashes($message1);
      $subject=stripslashes($subject1);

$from=$webmasteremail;
    	$header = "From: $sitename<$from>\n";
if($eformat1==1) 
	$header .="Content-type: text/plain; charset=iso-8859-1\n";
else
	$header .="Content-type: text/html; charset=iso-8859-1\n";
	$header .= "Reply-To: <$from>\n";
	$header .= "X-Sender: <$from>\n";
	$header .= "X-Mailer: PHP4\n";
	$header .= "X-Priority: 3\n";
	$header .= "Return-Path: <$from>\n";

if($err==0)  mail($to,$subject,$message,$header);
}

?>