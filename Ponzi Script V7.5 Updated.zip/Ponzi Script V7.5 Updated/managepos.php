<?php
  session_start();
include "header.php";
include "config.php";
if (!isset($_SESSION["username_session"])) {
include "loginform.php";
}
else {
middle();
} 

function middle()
{
include "config.php";
	$id=$_SESSION["username_session"];
	$username=$_SESSION["username_session"];
	$rs = mysql_query("select * from users where Username='$id'");
	$arr=mysql_fetch_array($rs);
	$status=$arr[14];
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
              <tr>
                <td align="left" class="bodytext" colspan="2" valign="top">
<table border="0" width="98%"><tr><td><font face="verdana" size="3"><b><p align="center">Matrix Positions</b></font></p>
<br><font face=verdana size=2>
<?php
$totalpos=0;
$rsm=mysql_query("select ID,Name,fee,levels from membershiplevels order by ID");
while($arrm=mysql_fetch_array($rsm)) {
$levels=$arrm[3];
$rsm1=mysql_query("select * from matrix$arrm[0] where Username='$username' order by ID");
$totalpos=$totalpos+mysql_num_rows($rsm1);

if(mysql_num_rows($rsm1)>0) {
$rc=0;
    echo("<br><b>$arrm[1]:</b><br><br><table width=98% border=1 cellspacing=0 cellpadding=0><tr><td align=center width=70><font face=verdana size=2><b>#</b></font></td><td align=center><font face=verdana size=2><b>Matrix ID</b></font></td>");

for($i=1;$i<=$levels;$i++)
echo "<td align=center><font face=verdana size=2><b>Level$i</b></font></td>";

echo("<td width=70 align=center><font face=verdana size=2><b>Total Earned</b></font></td><td align=center><font face=verdana size=2><b>Purchased Date</b></font></td><td align=center><font face=verdana size=2><b>Activation Date</b></font></td></tr>");
    while($rs=mysql_fetch_row($rsm1))
    {
$rc++;
if($rs[16]==$rs[18]) $cycled="Not yet";
else $cycled="$rs[18]";
      echo("<tr><td align=center><font face=verdana size=2>".$rc."</font></td><td align=center><font face=verdana size=2>". $rs[0]."</font></td>");

for($i=1;$i<=$levels;$i++) {
if($rs[3+$i]>0) 
echo "<td align=center><font face=verdana size=2><a href=moreinfo.php?m=$arrm[0]&l=$i&id=$rs[0]>".$rs[3+$i]."</a></font></td>";
else 
echo "<td align=center><font face=verdana size=2>".$rs[3+$i]."</font></td>";
}

echo("<td align=center><font face=verdana size=2>$". $rs[15]."</font></td><td align=center><font face=verdana size=2>". $rs[16]."</font></td><td align=center><font face=verdana size=2>".$cycled."</font></td></tr>");
    }
    echo("</table>");
 }

}
if($totalpos==0) {
	echo "<br><center><b>No Matrix Position Details Found</b></center><br>";
}
?>
</td> 
</tr>

	</table>
</td></tr>
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
</table>
<?php   return 1;
} include "footer.php";
?>