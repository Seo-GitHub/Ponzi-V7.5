				<form action=login.php method=post>
				<table align="center" cellpadding="0" cellspacing="0" border="0">
					<tr>
						<td class="login-right-box-top">Member Login</td>
					</tr>
					<tr>
						<td class="login-right-box-middal">
							<table width="370" style=" padding-top: 10px;" align="center" cellpadding="3" cellspacing="0" border="0">
								<tr>
									<td width="80px" align="left" valign="middal" class="login-box-from-text ">UserName : </td>
									<td><input name="id" class="login-box-from-text-use-box" type="text"  id="textfield5"  /></td>
								</tr>
								<tr>
									<td width="92px" align="left" valign="middal" class="login-box-from-text ">Password : </td>
									<td><input name="password" class="login-box-from-text-use-box-pass" type="password"  id="textfield5"  /></td>
								</tr>
								<tr>
									<td></td>
									<td align="center" class="forget-text"><a href="forgot.php">Forgot Your Password?</a></td>
								</tr>
								<tr>
									<td></td>
									<td align="center"><input type=submit value="Submit">
									<? /*
									<input type=submit src="images/login.jpg" value='Submit'>
									*/ ?>
									</td>
									
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td class="login-right-box-bot"></td>
					</tr>
				</table>
				</form>
