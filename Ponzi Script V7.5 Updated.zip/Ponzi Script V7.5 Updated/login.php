<?php
  session_start();
include "config.php";
include "func.php";
$a="";
$b="";
if ($_POST) {
	$a=validatet($_POST["id"]);
	$b=validatet($_POST["password"]);
}
if ($a=="" || $b=="")
{

if (!isset($_SESSION["username_session"])) {
include "header.php";
include "loginform.php";
}
else {
  middle();
}
}
else
{
$check=0;

$username=$a;
if($freemember==0) 
$rs = mysql_query("select * from users where Username='$username' and Password='$b' and active=1 and status=2");
else
$rs = mysql_query("select * from users where Username='$username' and Password='$b' and active=1");

if (mysql_num_rows($rs)>0) {
$arr=mysql_fetch_array($rs);
		$check=1;
		$_SESSION["username_session"]=$arr[8];
		$_SESSION["password_session"]=$arr[9];
		middle();
}
if ($check==0)
{
$rs = mysql_query("select * from users where Username='$a' and Password='$b' and active=0");
$rs1 = mysql_query("select * from users where Username='$a' and Password='$b' and active=1 and status=1");
if(mysql_num_rows($rs)>0) $check=3;
//if((mysql_num_rows($rs1)>0)&&($freemember==0)) $check=4;
include "header.php";
  if($check==0) {
  print "<h2 align=center>Invalid Username or Password.</h2>";
  }
  elseif($check==4) {
  print "<h3 align=center>You need to purchase a matrix position in order to activate your account.</h3>";
  }
  elseif($check==3) {
  print "<h3 align=center>You hadn't activated your account yet by clicking on activation link.<br>If you hadn't received the confirmation email yet <A href=resendv.php>Click Here</a> to resend your confirmation email.</h3>";
  }
include "loginform.php";
} 
}

function middle()
{
include "header.php";
include "config.php";
	$id=$_SESSION["username_session"];
	$rs = mysql_query("select * from users where Username='$id'");
	$arr=mysql_fetch_array($rs);
	$check=1;
	$email=$arr[7];
        $name=$arr[1];
	$ref=$arr[11];
	$username=$_SESSION[username_session];
	$status=$arr[14];
	if($status==1) {
		$statust="Free";
	}
	else {
		$statust="Pro";
	}
	$total=$arr[15];
	$paid=$arr[17];
	$unpaid=$arr[16];

?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
              <tr>
                <td align="left" class="bodytext" colspan="2" valign="top">
<table border="0" width="98%"><tr><td>
<?php
$rs=mysql_query("select * from pages where ID=3");
$arr=mysql_fetch_array($rs);

$arr[2]=str_replace("{sitename}",$sitename,$arr[2]);
$arr[2]=str_replace("{name}",$name,$arr[2]);

echo stripslashes($arr[2]);
?>
</td></tr></table>


</td></tr>
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
</table>
<?php }
include "footer.php";
?>