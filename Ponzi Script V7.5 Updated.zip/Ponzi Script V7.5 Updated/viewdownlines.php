<?php
  session_start();

include "header.php";
include "config.php";
if (!isset($_SESSION["username_session"])) {
include "loginform.php";
}
else {
  middle();
}

function middle()
{
include "config.php";


if (isset($_SESSION["username_session"])) {
	$id=$_SESSION["username_session"];
	if ($id=="") {
		$id=$username_session;
	}
	$rs = mysql_query("select * from users where Username='$id'");
	$arr=mysql_fetch_array($rs);
	$check=1;
	$email_session=$arr[7];
	$username_session=$arr[8];
	$password_session=$arr[9];
        $name_session=$arr[1];
	$ref_session=$arr[11];
	$status=$arr[14];
	if($status==1) {
		$statust="Free";
	}
	else {
		$statust="Pro";
	}
	$total_session=$arr[15];
	$paid_session=$arr[17];
	$unpaid_session=$arr[16];
	}


?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
              <tr>
                <td align="left" class="bodytext" colspan="2" valign="top">
<table border="0" width="98%"><tr><td><font face="verdana" size="3"><b><p align="center">Downline Details</b></font></p>
<br>
		<div align="center">
		<table border="0" cellpadding="3" cellspacing="0" width="500">
<?php include "config.php"; ?>

		      <tr> 
		        <td valign="center" align="left" colspan=2>
 <font face="Verdana" size="-1"><?php 
$rs1=mysql_query("select * from users where active=1 and ref_by='$_SESSION[username_session]'");
if(mysql_num_rows($rs1)>0) {
echo "<table width=600><tr>
<td width=150><font face=verdana size=2><b>Name</b></font></td>
<td width=100><font face=verdana size=2><b>Username</b></font></td>
<td width=150><font face=verdana size=2><b>Email</b></font></td>
<td width=100><font face=verdana size=2><b>Status</b></font></td>
<td width=100><font face=verdana size=2><b>Date Joined</b></font></td>
</tr>";


while($arr=mysql_fetch_array($rs1)) {
if($arr[14]==1) $status="Free";
else {
$status="Sponsor";
}
echo "<tr>
<td ><font face=verdana size=2>$arr[1]</font></td>
<td ><font face=verdana size=2>$arr[8]</font></td>
<td ><font face=verdana size=2><A href=mailto:$arr[7]>$arr[7]</a></font></td>
<td ><font face=verdana size=2>$status</font></td>
<td ><font face=verdana size=2>$arr[13]</font></td>
</tr>";
}
echo "</table>";
}
else {
echo "<center><br><b>No Downlines Found!</b><br></center>";
}
?></font><br></td>
		      </tr>
</table>
</td></tr></table>
</td></tr>
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
</table>
<?php }
include "footer.php";
?>