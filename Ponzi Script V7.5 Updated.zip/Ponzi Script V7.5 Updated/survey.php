<?php
  session_start();

include "header.php";
include "func.php";

if (!isset($_SESSION["username_session"])) {
include "loginform.php";
}
else {
middle();
} 

function middle()
{
include "config.php";
	$id=$_SESSION["username_session"];
	$rs = mysql_query("select * from users where Username='$id'");
	$arr=mysql_fetch_array($rs);
	$email=$arr[7];
$totban=$arr[20];
$banused=$arr[21];
$tottext=$arr[22];
$textused=$arr[23];
$id=(int)$_POST[id];
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
              <tr>
                <td align="left" class="bodytext" colspan="2" valign="top">
<table border="0" width="98%"><tr><td>
			<font face="verdana" size="3"><b>
			<p><center>Text Ad Advertisement</center></b></font></p><font face=verdana size=2><br>
<?php
$unused=$tottext-$textused;
if(!$_POST) echo "<br><b>Text Ads Credits Available $unused</b><br>";

  $sql = "Select * from memberstextads where Username='". $_SESSION["username_session"] ."'";
  $result1 = mysql_query($sql);
  $numm1 = mysql_num_rows($result1);


if($_POST[b]=="Add") {
  $a[1]=trim($_POST[burl]);
  $a[1]=addslashes($a[1]);
  $a[2]=validatet($_POST[wurl]);
  $a[3]=trim($_POST[textad]);
$a[3]=addslashes($a[3]);
$credits=(int)$_POST[credits];
if($a[1]=="") {
echo "<b><br>Invalid Text</b><br>";
}
elseif(($a[2]=="")||($a[2]=="http://")) {
echo "<b><br>Invalid Website Url</b><br>";
}
elseif($credits>$unused) {
echo "<b><br>You don't have enough credits to add this Text Ad</b><br>";
}
elseif($credits<1) {
echo "<b><br>Invalid credits!</b><br>";
}
else {
$sql_i="insert into memberstextads(Username,Textad,WebsiteURL,assigned,remaining,hits,approved,Date,Textad1) values('$_SESSION[username_session]','$a[1]','$a[2]',$credits,$credits,0,0,now(),'$a[3]')";
$rsi=mysql_query($sql_i);
mysql_query("update users set textadsused=textadsused+$credits where Username='$_SESSION[username_session]'");
echo "<br><br><b>Your text ad has been submited, and is waiting for the admin approval.</b><br>";
}
}
elseif($_POST[b]=="Preview") {
$credits=(int)$_POST[credits];
if($_POST[burl]=="") {
echo "<b><br>Invalid Text Ad</b><br>";
}
elseif($_POST[burl1]=="") {
echo "<b><br>Line1 Text Ad can't be blank</b><br>";
}
elseif($_POST[burl2]=="") {
echo "<b><br>Line2 Text Ad can't be blank</b><br>";
}
elseif($_POST[burl3]=="") {
echo "<b><br>Line3 Text Ad can't be blank</b><br>";
}
elseif(($_POST[wurl]=="")||($_POST[wurl]=="http://")) {
echo "<b><br>Invalid Website Url</b><br>";
}
elseif($credits>$unused) {
echo "<b><br>You don't have enough credits to add this Text Ad</b><br>";
}
elseif($credits<1) {
echo "<b><br>Invalid credits!</b><br>";
}
else { 
  $a[2]=trim($_POST[wurl]);
$a[2]=str_replace("\"","",$a[2]);
$a[2]=str_replace("'","",$a[2]);

$textad=addslashes("$_POST[burl1]<br>$_POST[burl2]<br>$_POST[burl3]");
echo "<form action='' method=post><input type=hidden name=burl value=\"$_POST[burl]\"><input type=hidden name=textad value=\"$textad\"><input type=hidden name=wurl value=$a[2]><input type=hidden name=credits value=$credits>";
echo "<a href='$a[2]' target=_blank>".stripslashes($_POST[burl])."</a><br>".stripslashes($textad);
echo "<br>If this text ad is appearing correct, then press the Add button. If it is not appearing correct, then go back to the previous page, and change the text ad.<br><input type=submit name=b value=Add></form>";
}
}
elseif($_POST[b]=="Edit") {
if($_POST[edit1]=="") {
$rs=mysql_query("select * from memberstextads where ID=$id and Username='$_SESSION[username_session]'");
if(mysql_num_rows($rs)>0) {
$arr=mysql_fetch_array($rs);
$textad=split("<br>",$arr[9]);
$line1=$textad[0];
$line2=$textad[1];
$line3=$textad[2];
echo "<form action='' method=post><input type=hidden name=id value=$id>
<input type=hidden name=edit1 value=edit>
<table>
<tr><td>Subject:</td><td><input type=text name=burl value=\"$arr[2]\"></td></tr>
<tr><td>Line1 Text Ad:</td><td><input type=text name=burl1 value=\"$line1\"></td></tr>
<tr><td>Line2 Text Ad:</td><td><input type=text name=burl2 value=\"$line2\"></td></tr>
<tr><td>Line3 Text Ad:</td><td><input type=text name=burl3 value=\"$line3\"></td></tr>
<tr><td>Website Url:</td><td><input type=text name=wurl value=\"$arr[3]\"></td></tr>
<tr><td><font face=verdana size=2>Credits Available:</td><td><font face=verdana size=2>$arr[5]</td></tr><tr><td>Add Credits</td><td><input type=text name=credits size=5><font size=1 face=verdana> ( To subtract credits use '-' sign before credits)</font></td></tr>
<tr><td colspan=2><input type=submit name=b value=Edit></td></tr></table></form>";
}
}
else {
$rs=mysql_query("select * from memberstextads where ID=$id and Username='$_SESSION[username_session]'");
if(mysql_num_rows($rs)>0) {
$arr=mysql_fetch_array($rs);
$credits=$arr[4];
$rem=$arr[5];
$credits1=(int)$_POST[credits];
$newcredits=$credits1;//-$rem;

if($_POST[burl]=="") {
echo "<b><br>Invalid Text Ad</b><br>";
}
elseif($_POST[burl1]=="") {
echo "<b><br>Line1 Text Ad can't be blank</b><br>";
}
elseif($_POST[burl2]=="") {
echo "<b><br>Line2 Text Ad can't be blank</b><br>";
}
elseif($_POST[burl3]=="") {
echo "<b><br>Line3 Text Ad can't be blank</b><br>";
}
elseif(($_POST[wurl]=="")||($_POST[wurl]=="http://")) {
echo "<b><br>Invalid Website Url</b><br>";
}
elseif($credits1>$unused) {
echo "<b><br>You don't have enough credits to add this Text Ad</b><br>";
}
elseif($credits1<-$rem) {
echo "<b><br>Invalid credits!</b><br>";
}
else {
  $a[1]=trim($_POST[burl]);
$a[1]=addslashes($a[1]);
  $a[2]=trim($_POST[wurl]);
$a[2]=str_replace("\"","",$a[2]);
$a[2]=str_replace("'","",$a[2]);

$textad="$_POST[burl1]<br>$_POST[burl2]<br>$_POST[burl3]";
$textad=addslashes($textad);
if(($a[1]!=$arr[2])||($a[2]!=$arr[3])||($textad!=$arr[9])) {
$sql_i="update memberstextads set Textad='$a[1]',Textad1='$textad',WebsiteURL='$a[2]',approved=0 where ID=$id and Username='$_SESSION[username_session]'";
$rsi=mysql_query($sql_i);
echo "<br><br><b>Your text ad has been added, and is waiting for the admin approval .</b><br>";
}
$sql_i="update memberstextads set assigned=assigned+$newcredits,remaining=remaining+$newcredits where ID=$id and Username='$_SESSION[username_session]'";
$rsi=mysql_query($sql_i);
mysql_query("update users set textadsused=textadsused+$credits1 where Username='$_SESSION[username_session]'");


echo "<br><br><b>Credits updated successfully.</b><br>";

}
}
}
}
elseif($_POST[b]=="Delete") {
$rs=mysql_query("select * from memberstextads where ID=$id and Username='$_SESSION[username_session]'");
if(mysql_num_rows($rs)>0) {
$arr=mysql_fetch_array($rs);
	$rem=$arr[5];
    mysql_query("update users set textadsused=textadsused-$rem where Username='$_SESSION[username_session]'");
}
$rs=mysql_query("delete from memberstextads where ID=$id and Username='$_SESSION[username_session]'");
echo "<br><br><b>Text ad Successfully Deleted</b><br><br>";
}



if(!$_POST) {
if($numm1<$maxads) { ?>
<br><center><b>Add New Text Ad</b></center>
<form action='' method=post>
<table>
<tr><td><font face=verdana size=2>Subject:</td><td><input type=text name=burl maxlength=20 value=""></td></tr>
<tr><td><font face=verdana size=2>Line1 Text Ad:</td><td><input type=text name=burl1 maxlength=24 value=""></td></tr>
<tr><td><font face=verdana size=2>Line2 Text Ad:</td><td><input type=text name=burl2 maxlength=24 value=""></td></tr>
<tr><td><font face=verdana size=2>Line3 Text Ad:</td><td><input type=text name=burl3 maxlength=24 value=""></td></tr>
<tr><td><font face=verdana size=2>Website Url:</td><td><input type=text name=wurl value="http://"></td></tr>
<tr><td><font face=verdana size=2>Assign Credits:</td><td><input type=text name=credits value="<?php echo $unused; ?>"></td></tr>
<tr><td colspan=2><input type=submit name=b value="Preview"> </td></tr>
</table></form>


<?php
}



if($numm1>0) {
print "<font face=verdana size=2><br><b><br><center>Below are the Text Ad(s) added by you:</center> </b><br>";
$rsb=mysql_query("select * from memberstextads where Username='$_SESSION[username_session]'");

if(mysql_num_rows($rsb)>0) {
echo "<table width=400>";
while($arrb=mysql_fetch_array($rsb)) {
echo "<tr><td><font face=verdana size=2>Ad</td><td><font face=verdana size=2><a href=$arrb[3] target=_blank>".stripslashes($arrb[2])."</a><br>".stripslashes($arrb[9])."</td></tr>";
echo "<tr><td><font face=verdana size=2>No of credits:</td><td><font face=verdana size=2>".$arrb[4]."</td></tr>";
echo "<tr><td><font face=verdana size=2>No of credits used:</td><td><font face=verdana size=2>".($arrb[4]-$arrb[5])."</td></tr>";
echo "<tr><td><font face=verdana size=2>No of clicks:</td><td><font face=verdana size=2>$arrb[6]</td></tr>";

if($arrb[7]==0) {
echo "<tr><td colspan=2><font face=verdana size=2>Waiting for admin approval</td></tr>";
}
else {
echo "<tr><td colspan=2><form action='' method=post><input type=hidden name=id value=$arrb[0]><input type=submit name=b value=Edit> &nbsp; &nbsp; <input type=submit name=b value=Delete></form></td></tr>";
}
echo "<tr><td colspan=2><hr></td></tr>";
}
echo "</table>";

}
else {
echo "<br>No TextAds Stats Available<br>";
}
}

}


?>
</td></tr></table>


</td></tr>
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
</table>
<?php }
include "footer.php";
?>