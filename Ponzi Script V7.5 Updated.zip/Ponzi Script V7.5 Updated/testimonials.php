<?php
include "header.php";
include "config.php";

echo "<br><h3 align=center>Testimonials</h3><br>";
$p=$_GET[p];
if($p=="viewall") {
$rs1=mysql_query("Select * from testimonials where status=1 order by rand()");
}
else {
$rs1=mysql_query("Select * from testimonials where status=1 order by rand() limit 0,5");
}
if(mysql_num_rows($rs1)>0) {
?>
<br><p align=center><font face=verdana size=2>Read some of the comments from our satisfied members below.</FONT></P>
<?php
while($arr=mysql_fetch_array($rs1)) {
?>
<br><br>
            <DIV align=center>
            <CENTER>
            <TABLE id=AutoNumber6 
            style="BORDER-RIGHT: #ff0000 1px dotted; BORDER-TOP: #ff0000 1px dotted; BORDER-LEFT: #ff0000 1px dotted; BORDER-BOTTOM: #ff0000 1px dotted; BORDER-COLLAPSE: collapse" 
            cellSpacing=0 cellPadding=5 width="90%">
              <TBODY>
              <TR>
                <TD vAlign=top width="100%">
                  <P align=left><FONT face=Tahoma size=2><?php echo str_replace("\n","<br>",stripslashes($arr[2])); ?></font></p>
</TD></TR></TBODY></TABLE></CENTER></DIV>

<?php  } 

if($p!="viewall") {
$rs1=mysql_query("Select * from testimonials where status=1 order by rand()");
$num=mysql_num_rows($rs1);
if($num>5) {
echo "<div align=right><font face=verdana size=2><a href=testimonials.php?p=viewall>Click Here to view all testimonials</a></font></div>";
}
}

} 

include "footer.php";
?>