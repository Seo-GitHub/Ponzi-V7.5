<?php
include "config.php";
$rs=mysql_query("select ID,ref_by from matrix2 where ref_by=2000009");
echo mysql_num_rows($rs);

$rs=mysql_query("select ID,ref_by from matrix2 where ID=2000009");
while($arr=mysql_fetch_array($rs)) {
echo "<br>$arr[0]-$arr[1]<br>";
//mysql_query("update matrix2 set Level1=Level1-1 where ID=$arr[0]");

$rs1=mysql_query("select ID,ref_by from matrix2 where ID=$arr[1]");
while($arr1=mysql_fetch_array($rs1)) {
echo "<br>$arr1[0]-$arr1[1]<br>";
//mysql_query("update matrix2 set Level2=Level2-1 where ID=$arr1[0]");


$rs2=mysql_query("select ID,ref_by from matrix2 where ID=$arr1[1]");
while($arr2=mysql_fetch_array($rs2)) {
echo "<br>$arr2[0]-$arr2[1]<br>";
//mysql_query("update matrix2 set Level3=Level3-1 where ID=$arr2[0]");


$rs3=mysql_query("select ID,ref_by from matrix2 where ID=$arr2[1]");
while($arr3=mysql_fetch_array($rs3)) {
echo "<br>$arr3[0]-$arr3[1]<br>";
//mysql_query("update matrix2 set Level4=Level4-1 where ID=$arr3[0]");


}
}
}
}

$rs=mysql_query("select ID,ref_by from matrix2 where ref_by=2000009");
echo mysql_num_rows($rs);
?>