<?php
include "header.php";
include "config.php";


$rs=mysql_query("select * from pages where ID=2");
$arr=mysql_fetch_array($rs);

echo stripslashes($arr[2]);


include "footer.php";
?>
