<?php
  session_start();

  include "header.php";
  include "config.php";
  include "func.php";

if (!isset($_SESSION["username_session"])) {
include "loginform.php";
}
else {

  if (!$_POST) 
  {
	middle();
  }

    elseif ($_POST["fname"]!="" && $_POST["pwd"]!="")

  {
 	if($_SESSION[password_session]==$_POST["pwd"])
	{

    print "<center><b>Your Account has been updated successfully<br></b></center>";
	$db_field[1]=validatet($_POST["fname"]);
        $db_field[2]=validatet($_POST["add"]);
        $db_field[3]=validatet($_POST["city"]);
        $db_field[4]=validatet($_POST["state"]);
        $db_field[5]=validatet($_POST["pzcode"]);
        $db_field[6]=validatet($_POST["country"]);
        $db_field[7]=validatet($_POST["phone"]);
if($_POST[subscribe]==1) {
mysql_query("update users set subscribed=1 where Username='$_SESSION[username_session]'");
}
		mysql_query("update users set Name='$db_field[1]' where Username='$_SESSION[username_session]'");
		mysql_query("update users set Address='$db_field[2]' where Username='$_SESSION[username_session]'");
		mysql_query("update users set City='$db_field[3]' where Username='$_SESSION[username_session]'");
		mysql_query("update users set State='$db_field[4]' where Username='$_SESSION[username_session]'");
		mysql_query("update users set Zip='$db_field[5]' where Username='$_SESSION[username_session]'");
		mysql_query("update users set Country='$db_field[6]' where Username='$_SESSION[username_session]'");
		mysql_query("update users set Phone='$db_field[7]' where Username='$_SESSION[username_session]'");
        $db_field[10]=validatet($_POST["npwd"]);
        $db_field[11]=validatet($_POST["cpwd"]);
        if($db_field[10]!="") {
         if($db_field[10]==$db_field[11]) {
		$query="update users set Password='$db_field[10]' where Username='$_SESSION[username_session]'";
		$rs = mysql_query($query);
$_SESSION["password_session"]=$db_field[10];
         }
        else {
	    print "<center><b>Password can't be updated because New Password and Confirm password doesn't match!<br></b></center>";
        }
        }

        }
	else
	{
	    print "<center><b>Invalid Password! Account cannot be updated!<br></b></center>";
	}

    middle();
  } 
  else {
    middle();
  }

}


function middle()
  {
include "config.php";
		$username=$_SESSION["username_session"];
		$rs = mysql_query("select * from users where Username='$username'");
		$arr=mysql_fetch_array($rs);
			$name=$arr['Name'];
			$address=$arr['Address'];
			$city=$arr['City'];
			$state=$arr['State'];
			$zip=$arr['Zip'];
			$country=$arr['Country'];
			$password=$arr['Password'];
			$email=$arr['Email'];
			$phone=$arr['Phone'];
$status=$arr[14];
$subs=$arr[19];
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
              <tr>
                <td align="left" class="bodytext" colspan="2" valign="top">
<table border="0" width="98%"><tr><td><font face="verdana" size="3"><b><p align="center">Profile</b></font></p>
<br>
	<form method="post" action="update_pf.php">
	<table width="450" border="0" cellspacing="0" cellpadding="0" align="center">
                <tr align="center" valign="middle"> 
                  <td colspan="2"><b>Update your Personal Information</b></td>
                </tr>
                <tr align="left" valign="middle"> 
                  <td width="44%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">FULL
                    NAME*</font></b></td>
                  <td width="56%" height="40"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="fname" size="20" maxlength="40" value="<?php echo $name; ?>">
                    </font></b></td>
                </tr>
                <tr align="left" valign="middle"> 
                  <td width="44%" height="18"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">EMAIL 
                    ADDRESS* </font></b></td>
                  <td width="56%" height="40" align="left"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
		     &nbsp;&nbsp;&nbsp;<?php echo $email; ?>
                    </font></b></td>
                </tr>
<?php if($showaddress==1) { ?>
                <tr align="left" valign="middle"> 
                  <td width="44%" height="18"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">ADDRESS*</font></b></td>
                  <td width="56%" height="40" align="left"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="add" value="<?php echo $address; ?>">
                    </font></b></td>
                </tr>
<?php } ?>
<?php if($showcity==1) { ?>
                <tr align="left" valign="middle"> 
                  <td width="44%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">CITY*</font></b></td>
                  <td width="56%" height="40" align="left"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="city" size="15" maxlength="30" value="<?php echo $city; ?>">
                    </font></b></td>
                </tr>
<?php } ?>
<?php if($showstate==1) { ?>
                <tr align="left" valign="middle"> 
                  <td height="18" width="44%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">STATE*</font></b></td>
                  <td height="40" width="56%" align="left"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="state" size="15" maxlength="30" value="<?php echo $state; ?>">
                    </font></b></td>
                </tr>
<?php } ?>
<?php if($showcountry==1) { ?>
                <tr align="left" valign="middle"> 
                  <td height="18" width="44%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">COUNTRY*</font></b></td>
                  <td height="40" width="56%" align="left"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                   <input type="text" name="country" size="15" maxlength="30" value="<?php echo $country; ?>">
                   </font></b></td>
                </tr>
<?php } ?>
<?php if($showzip==1) { ?>
                <tr align="left" valign="middle"> 
                  <td width="44%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">PIN 
                    ZIP CODE*</font></b></td>
                  <td width="56%" height="40" align="left"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="pzcode" size="10" maxlength="20" value="<?php echo $zip; ?>">
                    </font></b></td>
                </tr>
<?php } ?>
                <tr align="left" valign="middle"> 
                  <td height="18" width="44%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">PHONE*</font></b></td>
                  <td height="40" width="56%" align="left"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                   <input type="text" name="phone" size="15" maxlength="30" value="<?php echo $phone; ?>">
                   </font></b></td>
                </tr>
<?php if($subs==0) { ?>
                <tr align="left" valign="middle">
                  <td height="18" width="44%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Resubscribe to Admin Mailing:</font></b></td>
                  <td height="40" width="56%" align="left"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type=checkbox name=subscribe value=1>
                    </td>
                </tr>
<?php } ?>
                <tr align="center" valign="middle"> 
                  <td colspan="2" height="40" ><b></b><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Fill in new password and confirm password if you want to update your password.</td></tr>
                <tr align="left" valign="middle"> 
                  <td width="44%" ><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">New PASSWORD* 
                   </font></b></td>
                  <td  width="56%" height="40" align="left"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="password" name="npwd" size="20" maxlength="40">
                    </font></b></td>
                </tr>
                <tr align="left" valign="middle"> 
                  <td width="44%" ><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Confirm PASSWORD* 
                    </font></b></td>
                  <td  width="56%" height="40" align="left"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="password" name="cpwd" size="20" maxlength="40">
                    </font></b></td>
                </tr>


                <tr align="left" valign="middle"> 
                  <td width="44%"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">PASSWORD* 
                    </font></b></td>
                  <td width="56%" height="40" align="left"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="password" name="pwd" size="20" maxlength="40">
                    </font></b></td>
                </tr>
	                <tr align="left" valign="middle"> 
                  <td width="100%" colspan=2><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
		You need to enter your password to update your information.
                    </font></b></td>
                </tr>
	
                <tr align="center" valign="middle"> 
                  <td colspan="2" height="40"><b></b><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="submit" value="Update">
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                    </font></b></td>
                </tr>
              </table>
  </form> 
  </td>
  </tr>
</table>

</td></tr>
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
</table>
<?php     return 1;
  }
include "footer.php";
?>