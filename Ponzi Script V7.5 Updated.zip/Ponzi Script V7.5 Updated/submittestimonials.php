<?php
  session_start();

include "header.php";
include "config.php";

if (!isset($_SESSION["username_session"])) {
include "loginform.php";
}
else {
  middle();
}


function middle()
{
include "config.php";
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
              <tr>
                <td align="left" class="bodytext" colspan="2" valign="top">
<table border="0" width="98%"><tr><td><font face="verdana" size="3"><b><p align="center">Submit Testimonials</b></font></p>
<br>
<font face=arial size=2>
<?php
if(!$_POST) { ?>
<center>
<form action="submittestimonials.php" method=post>
Your Testimonails:<br><textarea rows=10 cols=40 name=data></textarea>
<br>
<input type=submit value="Submit Testimonial">
</form></center>
<?php } else { 
$a[1]=$_SESSION[username_session];
$a[2]=addslashes($_POST["data"]);

if(($a[1]=="")||($a[2]=="")) {
echo "<br><b>Testimonial can't be blank</b>";
}
else {
$sql_i="insert into testimonials values ('$a[0]','$a[1]','$a[2]',0,now())";
$rs=mysql_query($sql_i);
echo("<br><br><b><font face=verdana size=2>Thanks for taking the time to submit your valuable testimonials about our service. <br>&nbsp;<br>&nbsp;<br>&nbsp;<br></b></font>");
}
}
?>
</div></td></tr></table>
</td></tr>
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
</table>

<?php
}
include "footer.php";
?>