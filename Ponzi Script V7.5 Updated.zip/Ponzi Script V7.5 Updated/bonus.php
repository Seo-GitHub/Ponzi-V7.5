<?php
  session_start();

include "header.php";
include "config.php";
if (!isset($_SESSION["username_session"])) {
include "loginform.php";
}
else {
middle();
} 

function middle()
{
include "config.php";
	$id=$_SESSION["username_session"];
	$rs = mysql_query("select * from users where Username='$id'");
	$arr=mysql_fetch_array($rs);
	$status=$arr[14];
	if($status==1) {
		$statust="Free";
$bonus=$freebonus;
	}
	else {
		$statust="Pro";
$bonus="";

$rsm=mysql_query("select ID,Name,bonusdownloads from membershiplevels order by ID");
while($arrm=mysql_fetch_array($rsm)) {
$rs1=mysql_query("select ID from matrix$arrm[0] where Username='$id'");
if(mysql_num_rows($rs1)>0) {
$arr1=mysql_fetch_array($rs1);
$rs1=mysql_query("select ID from gifts where matrixid=$arrm[0] and approved=1 and FUsername='$id'");
if(mysql_num_rows($rs1)>0) {
$arrm[2]=stripslashes($arrm[2]);
$bonus.="<br><b>$arrm[1] Bonus</b><br>$arrm[2]<hr>";
}
}
}

	}
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
              <tr>
                <td align="left" class="bodytext" colspan="2" valign="top">
<table border="0" width="98%"><tr><td><font face="verdana" size="3"><b><p align="center">Bonus</b></font></p>
<br>
<?php
echo stripslashes($bonus);
?>
</td> 
</tr>

	</table>
</td></tr>
              <tr>
                <td height="10" colspan="2">&nbsp;</td>
              </tr>
</table>
<?php   return 1;
} include "footer.php";
?>