<?php
include "header.php";
include "config.php";
  include "func.php";
$id=(int)$_GET[id];
$username=validatet($_GET[username]);
if ($id=="" || $username=="")
{
  ?>
  <br><br>
  <blockquote>
  <p align="center"><font size="3" face="Verdana, Arial, Helvetica, sans-serif"><b>Invalid
  Confirmation Link!</b></font></p><br><br><br>
  <?php
}
else
{
  $sql = "Select * from users where ID=".$id." and Username='".$username."'";
  $result = mysql_query($sql);
  $total = mysql_num_rows($result);
  $rs  =  mysql_fetch_row($result);

  if ($total <1)
  {
    ?>
    <br><br>
      <blockquote>
        <p align="center"><font size="3" face="Verdana, Arial, Helvetica, sans-serif"><b>Invalid
          Confirmation Link!</b></font></p><br><br><br>
    <?php
  }
  else
  {
    if ($rs[10]==1)
    {
      echo("<br><br><b><font size=3><center>You had already activated your account.<br><br>Now just login to your account and start using our service.<br><br><br></b>");
    }
    else
    {
      $sql_u = "Update users set active='1' where Username='" . $username ."'";
      $result_u = mysql_query($sql_u);

?>
<p align="left"><font size="2" face="Verdana"><b>Your Email Address has been validated now! </b><br>
<?php


echo("All features of our service are available to you immediately.<br>
You can <a href=login.php>Login now</a> and start using our service!<br>");

  $to = $rs[7];

$message1=$message2;
$message1=str_replace("{name}","$rs[1]",$message1);
$message1=str_replace("{email}","$rs[7]",$message1);
$message1=str_replace("{username}","$rs[8]",$message1);
$message1=str_replace("{password}","$rs[9]",$message1);
$message1=str_replace("{sitename}","$sitename",$message1);
$message1=str_replace("{siteurl}","$siteurl",$message1);

$subject1=str_replace("{name}","$rs[1]",$subject2);
$subject1=str_replace("{email}","$rs[7]",$subject1);
$subject1=str_replace("{username}","$rs[8]",$subject1);
$subject1=str_replace("{password}","$rs[9]",$subject1);
$subject1=str_replace("{sitename}","$sitename",$subject1);
$subject1=str_replace("{siteurl}","$siteurl",$subject1);
      $message=stripslashes($message1);
      $subject=stripslashes($subject1);

$from=$webmasteremail;
    	$header = "From: $sitename<$from>\n";
if($eformat2==1) 
	$header .="Content-type: text/plain; charset=iso-8859-1\n";
else
	$header .="Content-type: text/html; charset=iso-8859-1\n";
	$header .= "Reply-To: <$from>\n";
	$header .= "X-Sender: <$from>\n";
	$header .= "X-Mailer: PHP4\n";
	$header .= "X-Priority: 3\n";
	$header .= "Return-Path: <$from>\n";

  mail($to,$subject,$message,$header);

if($refnotification==1) {
$ref_by=$rs[11];
$rs1=mysql_query("select * from users where Username='$ref_by'");
if(mysql_num_rows($rs1)>0) {
$arr1=mysql_fetch_array($rs1);
$message1=$message3;
$message1=str_replace("{name}","$arr1[1]",$message1);
$message1=str_replace("{email}","$arr1[7]",$message1);
$message1=str_replace("{username}","$arr1[8]",$message1);
$message1=str_replace("{password}","$arr1[9]",$message1);
$message1=str_replace("{sitename}","$sitename",$message1);
$message1=str_replace("{siteurl}","$siteurl",$message1);
$message1=str_replace("{refname}","$rs[1]",$message1);
$message1=str_replace("{refemail}","$rs[7]",$message1);
$message1=str_replace("{refusername}","$rs[8]",$message1);


$subject1=str_replace("{name}","$arr1[1]",$subject3);
$subject1=str_replace("{email}","$arr1[7]",$subject1);
$subject1=str_replace("{username}","$arr1[8]",$subject1);
$subject1=str_replace("{password}","$arr1[9]",$subject1);
$subject1=str_replace("{sitename}","$sitename",$subject1);
$subject1=str_replace("{siteurl}","$siteurl",$subject1);
$subject1=str_replace("{refname}","$rs[1]",$subject1);
$subject1=str_replace("{refemail}","$rs[7]",$subject1);
$subject1=str_replace("{refusername}","$rs[8]",$subject1);

      $message=stripslashes($message1);
      $subject=stripslashes($subject1);

    $to = $arr1[7];
    	$header = "From: $sitename<$from>\n";
if($eformat3==1) 
	$header .="Content-type: text/plain; charset=iso-8859-1\n";
else
	$header .="Content-type: text/html; charset=iso-8859-1\n";
	$header .= "Reply-To: <$from>\n";
	$header .= "X-Sender: <$from>\n";
	$header .= "X-Mailer: PHP4\n";
	$header .= "X-Priority: 3\n";
	$header .= "Return-Path: <$from>\n";

    mail($to,$subject,$message,$header);
}
}

    }
  }
}
include "./footer.php";
?>