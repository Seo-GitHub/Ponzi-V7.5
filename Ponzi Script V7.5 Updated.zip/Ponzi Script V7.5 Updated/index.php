<?php
session_start();

include "func.php";
foreach($_GET as $k=>$v)
$id .=$k;
$id=validatet($id);
if($id !="") {
//if($_SESSION["refid_session"]=="") {
$_SESSION["refid_session"]=$id ;
//}
}
include "header.php";
include "config.php"; 

$rs=mysql_query("select count(*) from users where active=1");
$arr=mysql_fetch_array($rs);
$totalusers=$arr[0];

$rs=mysql_query("select * from pages where ID=1");
$arr=mysql_fetch_array($rs);
$arr[2]=str_replace("{sitename}",$sitename,$arr[2]);
$arr[2]=str_replace("{totalinvestment}",$totalinv,$arr[2]);
$arr[2]=str_replace("{membersearnings}",$memearn,$arr[2]);
$arr[2]=str_replace("{totalusers}",$totalusers,$arr[2]);
echo stripslashes($arr[2]);

include "footer.php";
?>
