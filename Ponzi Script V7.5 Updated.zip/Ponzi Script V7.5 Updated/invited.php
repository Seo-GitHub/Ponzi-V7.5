<p align="left"> &nbsp;<br><font face=verdana size=2><a href="login.php">Members Home</a><br><br> 
<a href="purchasepos.php">Purchase Position(s)</a><br><br>
<a href="managepos.php">Matrix Positions</a><br><br>
<a href="approvedgifts.php">Approved Gifts</a><br><br>
<a href="pendinggifts.php">Pending Gifts</a><br><br>
<a href="stats.php">Stats</a><br><br>
<a href="ads.php">Promotional Center</a><br><br>
<a href="banners.php">Banner Advertisement</a><br><br>
<a href="textadv.php">Text Ad Advertisement</a><br><br>
<a href="bonus.php">Bonus</a><br><br>
<a href="paymentinfo.php">Payment Info</a><br><br>
<a href="update_pf.php">Profile</a><br><br>
<a href="submittestimonials.php">Submit Testimonials</a><br><br>
<a href="logout.php">Logout</a>
</font></p>