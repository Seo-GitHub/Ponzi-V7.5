<?php
  session_start();

include "header.php";
include "config.php";
include "func.php";
$id=$_SESSION[refid_session];
$sname="";
if($id) {
$rs=mysql_query("select Name from users where Username='$id'");
if(mysql_num_rows($rs)>0) {
$arr=mysql_fetch_array($rs);
$sname=$arr[0];
}
}


if($_POST) {
	if($_POST['first_name'] == '') {
		$fnameError = 'You forgot to enter the First Name.';
	}
	if($_POST['last_name'] == '') {
		$lnameError = 'You forgot to enter the Last Name.';
	}
	if(($showaddress==1)&&($_POST['address'] == '')) {
		$addressError = 'You forgot to enter the Address.';
	}
	if(($showcity==1)&&($_POST['city'] == '')) {
		$cityError = 'You forgot to enter the City.';
	}
	if(($showstate==1)&&($_POST['state'] == '')) {
		$stateError = 'You forgot to enter the State.';
	}
	if(($showzip==1)&&($_POST['zip'] == '')) {
		$zipError = 'You forgot to enter the Zip.';
	}
	if(($showcountry==1)&&($_POST['country'] == '')) {
		$countryError = 'You forgot to enter the Country.';
	}
	if($_POST['phone'] == '') {
		$phoneError = 'You forgot to enter the Phone number.';
	} 
	if($_POST['username'] == '') {
		$usernameError = 'You forgot to enter the Username.';
	} elseif(!preg_match ("/^([[:alnum:]]+)$/", $_POST['username']))  {
		$usernameError = 'Username can contain only alpha numeric characters.';
	}
	if($_POST['password'] == '') {
		$passwordError = 'You forgot to enter the Password.';
	}
	if($_POST['cpassword'] == '') {
		$cpasswordError = 'You forgot to enter the Confirm Password.';
	} elseif($_POST[password]!=$_POST[cpassword]) {
		$cpasswordError = 'Password and Confirm Password doesn\'t match.';
	}
	if($_POST['email'] == '') {
		$emailError = 'You forgot to enter the email address.';
	} elseif(!preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $_POST['email'])) {
		$emailError = 'Enter a valid email address to send to.';
	}
   if( $_SESSION['security_code'] == $_POST['security_code'] && !empty($_SESSION['security_code'] ) ) {
 	} else {
$capError="Invalid Security Code.";
    }

$email=validatet($_POST[email]);
$username=validatet($_POST[username]);
      $check=0;
      $sql = "select * from users where Email='".$email."'";
      $result = mysql_query($sql);
      $total = mysql_num_rows($result);
      $rs  =  mysql_fetch_row($result);

      $sql1 = "select * from users where Username='".$username."'";
      $result1 = mysql_query($sql1);
      $total1 = mysql_num_rows($result1);
      $rs1  =  mysql_fetch_row($result1);

      if ($total > 0) {
          $check=1;
      }
      if($username=="admin") {
	$check=5;
      }
      if ($total1 > 0) {
          $check=3;
      }
    if ($check==1) {
		$emailError = 'Account with this email address already exists.';
    }
    elseif ($check==3) {
		$usernameError = 'Account with this username already exists.';
    }
    elseif ($check==5) {
		$usernameError = 'Account with this username already exists.';
    }


	if(!isset($emailError) && !isset($fnameError) && !isset($lnameError) && !isset($addressError) && !isset($cityError) && !isset($stateError) && !isset($zipError) && !isset($countryError) && !isset($usernameError) && !isset($phoneError) && !isset($passwordError) && !isset($cpasswordError) && !isset($capError)) {

  $space = " ";
  $a[1] = $_POST[first_name] . $space . $_POST[last_name];
	$a[1]=validatet($a[1]);
 if($showaddress==1)  $a[2]=validatet($_POST[address]); else $a[2]=" ";
 if($showcity==1)  $a[3]=validatet($_POST[city]); else $a[3]=" ";
 if($showstate==1)  $a[4]=validatet($_POST[state]); else $a[4]=" ";
 if($showzip==1)  $a[5]=validatet($_POST[zip]); else $a[5]=" ";
 if($showcountry==1)  $a[6]=validatet($_POST[country]); else $a[6]=" ";
  $a[7]=validatet($_POST[email]);
  $a[8]=validatet($_POST[username]);
	$a[8]=str_replace(" ","",$a[8]);
	$a[8]=strtolower($a[8]);
$username=$a[8];
  $a[9]=validatet($_POST[password]);
  $a[12]=$_SERVER['REMOTE_ADDR'];
  $a[13]=date("j M, Y");
  $a[14]=validatet($_POST[cpassword]);
  $a[15]=validatet($_POST[phone]);
  $ref_by=strtolower($_SESSION["refid_session"]);

$rs=mysql_query("select * from users where Username='$ref_by' and active=1");
if(mysql_num_rows($rs)<1) {
$ref_by="";
}


if($confirmreq==1) $aactive=0;
else $aactive=1;

      $sql_i="insert into users(Name,Address,City,State,Zip,Country,Email,Username,Password,active,ref_by,IP,Date,status,Total,Unpaid,Paid,RDate,subscribed,banners,bannersused,textads,textadsused,Payza,Egopay,Merchant1,Merchant2,Merchant3,Merchant4,Merchant5,Phone) values
              (
               '$a[1]',
               '$a[2]',
               '$a[3]',
               '$a[4]',
               '$a[5]',
               '$a[6]',
               '$a[7]',
               '$a[8]',
               '$a[9]',
               $aactive,
               '$ref_by',
               '$a[12]',
               now(),
		1,
		0.00,
		0.00,
		0.00,
		now(),1,0,0,0,0,'','','','','','','','$a[15]'
              )";
      $rs=mysql_query($sql_i);
      $b=mysql_insert_id();


if($confirmreq==1) {
      echo("<br><div align=left><font size=2 face='Verdana, Arial, Helvetica, sans-serif'>$a[1] Thank you for registering.<br>");
?>
A message has been sent to your email box: <?php echo $a[7]; ?>.
There's a link inside the email, click it. You will be returned to <?php echo $sitename;?>.  
It will activate your account. </b><br><br>
The e-mail is sent out instantly. If you do not received it within 10-15 minutes, we recommend you <a href=resendv.php>Click Here</a> to receive it again.<br>
If you are using free email address provider like yahoo/hotmail then please don't forget to check your junk/bulk folder as it may be delivered there.
<br><br>
Also don't forget to whitelist our email address <?php echo $webmasteremail; ?> so that you may receive all the future emails properly.
<br><br>
<?php
echo "</div><br>";
      echo("<br><br><br>");

$to = $a[7];

$validationurl="$siteurl/confirm.php?username=$a[8]&id=$b";
$message1=str_replace("{validationurl}","$validationurl",$message1);
$message1=str_replace("{name}","$a[1]",$message1);
$message1=str_replace("{email}","$a[7]",$message1);
$message1=str_replace("{username}","$a[8]",$message1);
$message1=str_replace("{password}","$a[9]",$message1);
$message1=str_replace("{sitename}","$sitename",$message1);
$message1=str_replace("{siteurl}","$siteurl",$message1);

$subject1=str_replace("{name}","$a[1]",$subject1);
$subject1=str_replace("{email}","$a[7]",$subject1);
$subject1=str_replace("{username}","$a[8]",$subject1);
$subject1=str_replace("{password}","$a[9]",$subject1);
$subject1=str_replace("{sitename}","$sitename",$subject1);
$subject1=str_replace("{siteurl}","$siteurl",$subject1);
      $message=stripslashes($message1);
      $subject=stripslashes($subject1);

$from=$webmasteremail;
    	$header = "From: $sitename<$from>\n";
if($eformat1==1) 
	$header .="Content-type: text/plain; charset=iso-8859-1\n";
else
	$header .="Content-type: text/html; charset=iso-8859-1\n";
	$header .= "Reply-To: <$from>\n";
	$header .= "X-Sender: <$from>\n";
	$header .= "X-Mailer: PHP4\n";
	$header .= "X-Priority: 3\n";
	$header .= "Return-Path: <$from>\n";

  mail($to,$subject,$message,$header);

} else {
      echo("<br><font size=2 face='Verdana, Arial, Helvetica, sans-serif'>");

      echo("<br><b>".$a[1]." Thank you for registering. <br>");
echo("Your Account have been Activated Now!<br>
All features of our service are available to you immediately.<br>
You can <a href=login.php>Login now</a> and start using our service!<br>");

      echo("</font><br>");

  $to = $a[7];

$message1=$message2;
$message1=str_replace("{name}","$a[1]",$message1);
$message1=str_replace("{email}","$a[7]",$message1);
$message1=str_replace("{username}","$a[8]",$message1);
$message1=str_replace("{password}","$a[9]",$message1);
$message1=str_replace("{sitename}","$sitename",$message1);
$message1=str_replace("{siteurl}","$siteurl",$message1);

$subject1=str_replace("{name}","$a[1]",$subject2);
$subject1=str_replace("{email}","$a[7]",$subject1);
$subject1=str_replace("{username}","$a[8]",$subject1);
$subject1=str_replace("{password}","$a[9]",$subject1);
$subject1=str_replace("{sitename}","$sitename",$subject1);
$subject1=str_replace("{siteurl}","$siteurl",$subject1);
      $message=stripslashes($message1);
      $subject=stripslashes($subject1);

$from=$webmasteremail;
    	$header = "From: $sitename<$from>\n";
if($eformat2==1) 
	$header .="Content-type: text/plain; charset=iso-8859-1\n";
else
	$header .="Content-type: text/html; charset=iso-8859-1\n";
	$header .= "Reply-To: <$from>\n";
	$header .= "X-Sender: <$from>\n";
	$header .= "X-Mailer: PHP4\n";
	$header .= "X-Priority: 3\n";
	$header .= "Return-Path: <$from>\n";

  mail($to,$subject,$message,$header);


if($refnotification==1) {
$rs1=mysql_query("select * from users where Username='$ref_by'");
if(mysql_num_rows($rs1)>0) {
$arr1=mysql_fetch_array($rs1);
$message1=$message3;
$message1=str_replace("{name}","$arr1[1]",$message1);
$message1=str_replace("{email}","$arr1[7]",$message1);
$message1=str_replace("{username}","$arr1[8]",$message1);
$message1=str_replace("{password}","$arr1[9]",$message1);
$message1=str_replace("{sitename}","$sitename",$message1);
$message1=str_replace("{siteurl}","$siteurl",$message1);
$message1=str_replace("{refname}","$a[1]",$message1);
$message1=str_replace("{refemail}","$a[7]",$message1);
$message1=str_replace("{refusername}","$a[8]",$message1);

$subject1=str_replace("{name}","$arr1[1]",$subject3);
$subject1=str_replace("{email}","$arr1[7]",$subject1);
$subject1=str_replace("{username}","$arr1[8]",$subject1);
$subject1=str_replace("{password}","$arr1[9]",$subject1);
$subject1=str_replace("{sitename}","$sitename",$subject1);
$subject1=str_replace("{siteurl}","$siteurl",$subject1);
$subject1=str_replace("{refname}","$a[1]",$subject1);
$subject1=str_replace("{refemail}","$a[7]",$subject1);
$subject1=str_replace("{refusername}","$a[8]",$subject1);

      $message=stripslashes($message1);
      $subject=stripslashes($subject1);

    $to = $arr1[7];
    	$header = "From: $sitename<$from>\n";
if($eformat3==1) 
	$header .="Content-type: text/plain; charset=iso-8859-1\n";
else
	$header .="Content-type: text/html; charset=iso-8859-1\n";
	$header .= "Reply-To: <$from>\n";
	$header .= "X-Sender: <$from>\n";
	$header .= "X-Mailer: PHP4\n";
	$header .= "X-Priority: 3\n";
	$header .= "Return-Path: <$from>\n";

    mail($to,$subject,$message,$header);
}
}

}

include "footer.php";
exit;
	}
}



?>
    <form action=join.php method=post>
    
				<table width="728px;" align="center" cellpadding="0" cellspacing="0" border="0">
					<tr>
						<td class="right-box-top">Complete The Form Below</td>
					</tr>
					<tr>
						<td class="right-box-bg">
							<table  width="434px" style="padding-top: 5px;" align="center" cellpadding="0" cellspacing="0" border="0">
								<tr>
									<td colspan="2" class="right-2-title">This will create your Account</td>
								</tr>
								<tr>
									
									<td width="140px"  class="from-text">Sponsor</td>

									<td  class="from-text"><?php echo $sname; ?></td>
								</tr>
								<tr>
									<td width="140px"  class="from-text">First Name<span class="color-red"> * </span></td>
									<td align="left" valign="middle"><input name="first_name" class="from-box-right-1" type="text" id="textfield5"  value="<?php echo validatet($_POST[first_name]); ?>" size=23> <?php if(isset($fnameError)) echo '<br><font face=verdana size=2>'.$fnameError.'</font>'; ?></td>
								</tr>
								<tr>
									<td width="140px"  class="from-text">Last Name<span class="color-red"> * </span></td>
									<td align="left" valign="middle"><input name="last_name" class="from-box-right-1" type="text" id="textfield5"  value="<?php echo validatet($_POST[last_name]); ?>" size=23><?php if(isset($lnameError)) echo '<br><font face=verdana size=2>'.$lnameError.'</font>'; ?></td>
								</tr>
								<?php if($showaddress==1) { ?>
								<tr>
									<td width="140px"  class="from-text">Address<span class="color-red"> * </span></td>
									<td align="left" valign="middle"><input name="address" class="from-box-right-1" type="text"  id="textfield5"  value="<?php echo validatet($_POST[address]); ?>" size=23><?php if(isset($addressError)) echo '<br><font face=verdana size=2>'.$addressError.'</font>'; ?></td>
								</tr>
								<?php } ?>
								<?php if($showcity==1) { ?>
								<tr>
									<td width="140px"  class="from-text">City <span class="color-red"> * </span></td>
									<td align="left" valign="middle"><input name="city" class="from-box-right-1" type="text"  id="textfield5"  value="<?php echo validatet($_POST[city]); ?>" size=23><?php if(isset($cityError)) echo '<br><font face=verdana size=2>'.$cityError.'</font>'; ?></td>
								</tr>
								<?php } ?>
								<?php if($showstate==1) { ?>
								<tr>
									<td width="140px"  class="from-text">State/Region<span class="color-red"> * </span></td>
									<td align="left" valign="middle"><input name="state" class="from-box-right-1" type="text"  id="textfield5" value="<?php echo validatet($_POST[state]); ?>" size=23><?php if(isset($stateError)) echo '<br><font face=verdana size=2>'.$stateError.'</font>'; ?></td>
								</tr>
								<?php } ?>
								<?php if($showzip==1) { ?>
								<tr>
									<td width="140px"  class="from-text">Postal Code<span class="color-red"> * </span></td>
									<td align="left" valign="middle"><input name="zip" class="from-box-right-1" type="text"  id="textfield5"   value="<?php echo validatet($_POST[zip]); ?>" size=23><?php if(isset($zipError)) echo '<br><font face=verdana size=2>'.$zipError.'</font>'; ?></td>
								</tr>
								<?php } ?>
								<?php if($showcountry==1) { ?>
								<tr>
									<td width="140px"  class="from-text">Country <span class="color-red"> * </span></td>
									<td align="left" valign="middle"><input name="country" class="from-box-right-1" type="text"  id="textfield5"   value="<?php echo validatet($_POST[country]); ?>" size=23><?php if(isset($countryError)) echo '<br><font face=verdana size=2>'.$countryError.'</font>'; ?></td>
								</tr>
								<?php } ?>
								<tr>
									<td width="140px"  class="from-text">Email Address<span class="color-red"> * </span></td>
									<td align="left" valign="middle"><input name="email" class="from-box-right-1" type="text"  id="textfield5"   value="<?php echo validatet($_POST[email]); ?>" size=23><?php if(isset($emailError)) echo '<br><font face=verdana size=2>'.$emailError.'</font>'; ?></td>
								</tr>
								<tr>
									<td width="140px"  class="from-text">Phone <span class="color-red"> * </span></td>
									<td align="left" valign="middle"><input name="phone" class="from-box-right-1" type="text"  id="textfield5"  value="<?php echo validatet($_POST[phone]); ?>" size=23><?php if(isset($phoneError)) echo '<br><font face=verdana size=2>'.$phoneError.'</font>'; ?></td>
								</tr>
								<tr>
									<td width="140px"  class="from-text">Username <span class="color-red"> * </span></td>
									<td align="left" valign="middle"><input name="username" class="from-box-right-1" type="text"  id="textfield5"  value="<?php echo validatet($_POST[username]); ?>" size=23><?php if(isset($usernameError)) echo '<br><font face=verdana size=2>'.$usernameError.'</font>'; ?></td>
								</tr>
								<tr>
									<td width="140px"  class="from-text">Password <span class="color-red"> * </span></td>
									<td align="left" valign="middle"><input name="password" class="from-box-right-1" type="text"  id="textfield5"  value="<?php echo validatet($_POST[password]); ?>" type=password size=23><?php if(isset($passwordError)) echo '<br><font face=verdana size=2>'.$passwordError.'</font>'; ?></td>
								</tr>
								<tr>
									<td width="140px"  class="from-text">Confirm Password <span class="color-red"> * </span></td>
									<td align="left" valign="middle"><input name="cpassword" class="from-box-right-1" type="text"  id="textfield5"  value="<?php echo validatet($_POST[cpassword]); ?>" type=password size=23><?php if(isset($cpasswordError)) echo '<br><font face=verdana size=2>'.$cpasswordError.'</font>'; ?></td>
								</tr>
								<tr>
									<td width="140px"  class="from-text">Security Code <span class="color-red"> * </span></td>
									<td align="left" valign="middle">
										<table width="100%" align="center" cellpadding="0" cellspacing="0" border="0">
											<tr>
												<td width="110px"><img src="CaptchaSecurityImages.php?width=100&height=40&characters=5" /></td>
												<td align="left"><input name="security_code" class="captch-box" type="text"  id="textfield5"  /><?php if(isset($capError)) echo '<br><font face=verdana size=2>'.$capError.'</font>'; ?></td>
											</tr>
											
										</table>
									</td>
								</tr>
								<tr >
									<td colspan="2" class="login-in-box-text" >You are <span class="color-red"><b><a href="terms.php"> agreeing</a> </b></span>to our <span class="color-red"><b><a href="terms.php">Terms and Conditions </a> </b></span> by pressing the Submit Button</td>
								</tr>
								<tr>
									<td  align="center" colspan="2"><input type=submit class="join-now-button" value='Join Ultimate Matrix Demo'></td>
								</tr>
								
							</table>
						</td>
					</tr>
					<tr>
						<td class="right-box-bot"></td>
					</tr>
				</table></FORM>
  <?php
include "footer.php";
?>