<?php
include "header.php";
include "config.php";
include "func.php";

$a=validatet($_POST[Email]);
if ($a=="")
{
  ?>
  <div align="left">
   <table width="100%" border="0" cellspacing="2" cellpadding="2">
    <tr>
      <td rowspan="23" align="center" valign="top" width="72%" >
        <form action='' method=post>
          <div align="center">
            <p><font color="#0000CC"><br><br><b>Resend Verification Email</b></font></p>
            <p align="center"> <font size="-1">Please enter&nbsp;the Email
              address you used to register at </font><font color="#000040"><b><?php echo($sitename) ; ?></b></font><font size="-1"><font size="-1">
              and then press submit.</font></font> <font size="-1" color="#D64200">
              </font><font size="-1"> <br>
              <input name="Email" size="30" >
              <br>
              </font></p>
          </div>
          <p align="center"><small>
            <input type="submit" value="Submit">
            </small></p>
          <p>Your confirmation email will be sent to you within few minutes.
          </p>
        </form>
        <p align="center">&nbsp;</p>
      </td>
    </tr>
  </table>
  </div>
  <?php
}
else
{
  $sql = "Select * from users where Email='".$a."'";
  $result = mysql_query($sql);
  $total = mysql_num_rows($result);
  $rs  =  mysql_fetch_row($result);
  if ($total < 1)
  {
    echo("<b><br><br><br><center>Sorry, this Email Address doesn't exist in our member database.<br></center></b>");
    ?>
  <div align="left">
   <table width="100%" border="0" cellspacing="2" cellpadding="2">
    <tr>
      <td rowspan="23" align="center" valign="top" width="72%" >
        <form action='' method=post>
          <div align="center">
            <p><font color="#0000CC"><br><br><b>Resend Verification Email</b></font></p>
            <p align="center"> <font size="-1">Please enter&nbsp;the Email
              address you used to register at </font><font color="#000040"><b><?php echo($sitename) ; ?></b></font><font size="-1"><font size="-1">
              and then press submit.</font></font> <font size="-1" color="#D64200">
              </font><font size="-1"> <br>
              <input name="Email" size="30" >
              <br>
              </font></p>
          </div>
          <p align="center"><small>
            <input type="submit" value="Submit">
            </small></p>
          <p>Your confirmation email will be sent to you within few minutes.
          </p>
        </form>
        <p align="center">&nbsp;</p>
      </td>
    </tr>
  </table>
  </div>
   <?php
  }
  else
  {
      if($rs[10]==1) {
echo "<br><br><b>Your account is already active.<br><a href=login.php>Click Here</a> to login to your account.<br></b><br>";
	}
	else {

$to=$rs[7];

$validationurl="$siteurl/confirm.php?username=$rs[8]&id=$rs[0]";
$message1=str_replace("{validationurl}","$validationurl",$message1);
$message1=str_replace("{name}","$rs[1]",$message1);
$message1=str_replace("{email}","$rs[7]",$message1);
$message1=str_replace("{username}","$rs[8]",$message1);
$message1=str_replace("{password}","$rs[9]",$message1);
$message1=str_replace("{sitename}","$sitename",$message1);
$message1=str_replace("{siteurl}","$siteurl",$message1);

$subject1=str_replace("{name}","$rs[1]",$subject1);
$subject1=str_replace("{email}","$rs[7]",$subject1);
$subject1=str_replace("{username}","$rs[8]",$subject1);
$subject1=str_replace("{password}","$rs[9]",$subject1);
$subject1=str_replace("{sitename}","$sitename",$subject1);
$subject1=str_replace("{siteurl}","$siteurl",$subject1);
      $message=stripslashes($message1);
      $subject=stripslashes($subject1);

$from=$webmasteremail;
    	$header = "From: $sitename<$from>\n";
if($eformat1==1) 
	$header .="Content-type: text/plain; charset=iso-8859-1\n";
else
	$header .="Content-type: text/html; charset=iso-8859-1\n";
	$header .= "Reply-To: <$from>\n";
	$header .= "X-Sender: <$from>\n";
	$header .= "X-Mailer: PHP4\n";
	$header .= "X-Priority: 3\n";
	$header .= "Return-Path: <$from>\n";


  mail($to,$subject,$message,$header);

    echo("<br><br><br><font face=verdana size=2><center>Your Verification Email has been sent to your Email Address!<br><br></center>
<div align=left>
If you do not received it within 10-15 minutes, we recommend you <a href=resendv.php>Click Here</a> to receive it again.<br>
If you are using free email address provider like yahoo/hotmail then please don't forget to check your junk/bulk folder as it may be delivered there.
<br><br>
Also don't forget to whitelist our email address $webmasteremail so that you may receive all the future emails properly.
</div></font>
<br><br><br><br>");
	}
  }
}

include "footer.php";
?>