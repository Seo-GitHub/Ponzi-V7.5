<?php
session_start();
include "header.php";
include "config.php";
include "func.php";

if($_POST) {
	if($_POST['name'] == '') {
		$nameError = 'You forgot to enter the name.';
	}
	if($_POST['email'] == '') {
		$emailError = 'You forgot to enter the email address.';
	} elseif(!preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $_POST['email'])) {
		$emailError = 'Enter a valid email address.';
	}
	if($_POST['subject'] == '') {
		$subjectError = 'You forgot to enter the subject.';
	}
	
	if($_POST['message'] == '') {
		$messageError = 'You forgot to enter the message.';
	}
   if( $_SESSION['security_code'] == $_POST['security_code'] && !empty($_SESSION['security_code'] ) ) {
 	} else {
$capError="Invalid Security Code.";
    }


	if(!isset($emailError) && !isset($nameError) && !isset($subjectError) && !isset($messageError) && !isset($capError)) {
      $to = $webmasteremail;
      $subject = "Help Request for ".$sitename;
      $from = validatet($_POST["email"]);
      $message="A Visitor at your website had submitted this help request.

Name:".validatet($_POST[name])."
Email:".validatet($_POST[email])."
Subject:".validatet($_POST["subject"])."
Message:".validatet($_POST["message"]);
    	$header = "From: $from<$from>\n";
	$header .="Content-type: text/plain; charset=iso-8859-1\n";
	$header .= "Reply-To: <$from>\n";
	$header .= "X-Sender: <$from>\n";
	$header .= "X-Mailer: PHP4\n";
	$header .= "X-Priority: 3\n";
	$header .= "Return-Path: <$from>\n";

      mail($to,$subject,$message,$header);

echo "<br><br><br><br><b><font face=verdana size=2>Your Request have been submitted.<br>
One of our Customer Representative will reply you soon.</b><br><br><br><br>";
include "footer.php";
exit;

	}
}

?>
<br> 
      <h2 align=center>Contact Us</h2>
<table width=550 align=center>
<form action=contactus.php method=post>
<tr><td align=left width=10%>&nbsp;</td><td align=left width=30%><font size=2 face=verdana>Your Name:</font></td>
<td align=left width=60%><input type=text name="name" value="<? echo validatet($_POST[name]); ?>"><?php if(isset($nameError)) echo '<br><font face=verdana size=2>'.$nameError.'</font>'; ?></td></tr>
<tr><td align=left width=10%>&nbsp;</td><td align=left><font size=2 face=verdana>Your Email:</font></td>
<td align=left><input type=text name="email" value="<? echo validatet($_POST[email]); ?>"><?php if(isset($emailError)) echo '<br><font face=verdana size=2>'.$emailError.'</font>'; ?></td></tr>
<tr><td align=left width=10%>&nbsp;</td><td align=left><font size=2 face=verdana>Subject:</font></td>
<td align=left><input type=text name="subject" value="<? echo validatet($_POST[subject]); ?>"><?php if(isset($subjectError)) echo '<br><font face=verdana size=2>'.$subjectError.'</font>'; ?></td></tr>
<tr><td align=left width=10%>&nbsp;</td><td align=left><font size=2 face=verdana>Message:</font></td>
<td align=left><textarea name="message" rows=5 cols=25><? echo validatet($_POST[message]); ?></textarea><?php if(isset($messageError)) echo '<br><font face=verdana size=2>'.$messageError.'</font>'; ?></td></tr>
<tr><td align=left width=10%>&nbsp;</td><td align=left><font size=2 face=verdana>Security Code:</font></td>
<td align=left><img src="CaptchaSecurityImages.php?width=100&height=40&characters=5" /><input id="security_code" name="security_code" type="text" /><?php if(isset($capError)) echo '<br><font face=verdana size=2>'.$capError.'</font>'; ?></td></tr>

<tr><td colspan=3 align=center><input type=submit value="submit"></td></tr></table></form>
<br> <br> <br>
<?
include "footer.php";
?>