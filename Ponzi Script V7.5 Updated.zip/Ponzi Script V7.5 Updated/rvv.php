<?php
  // CONNECTING TO DATABASE
 include "./config.php";

$id =(int)$_GET[id];
      $sql = "select WebsiteURL from memberstextads where id=". $id;
      $result = mysql_query($sql);
if(mysql_num_rows($result)>0) {
      $arr = mysql_fetch_array($result);
$rs=mysql_query("update memberstextads set hits=hits+1 where id=$id");
mysql_close($dbconnect);
	header("Location:".$arr[0]);
}
else {
echo "<br><b>Invalid Url</b><br>";
}
mysql_close($dbconnect);
?>